import java.util.Scanner;

public class SittingTime 
{

	/** This program calculates the number of times a person stood up in a single day, and the
	 * average amount of time that the person spent sitting.
	 * 
	 * @param args There are no command line arguments
	 */
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		final double INCREMENT = 0.5;
		final double STARTING_TIME = 8.0; // 8 a.m.
		final double ENDING_TIME = 17.0;  // 5 p.m.
		
		int stand = 0;
		double time = STARTING_TIME;
		
		// Step through the day, one INCREMENT at a time
		while (time < ENDING_TIME)
		{
			System.out.println("How many times did you get between " + time + " and " + (time + INCREMENT));
			int data = input.nextInt();
			stand = stand + data;
			
			time = time + INCREMENT;
		}
		
		//Report results to user
		System.out.println("You got up " + stand + " times today.");
		System.out.println("Your average time sitting between standing was: " + (8.0 / stand));
		
		input.close();
	}

}
