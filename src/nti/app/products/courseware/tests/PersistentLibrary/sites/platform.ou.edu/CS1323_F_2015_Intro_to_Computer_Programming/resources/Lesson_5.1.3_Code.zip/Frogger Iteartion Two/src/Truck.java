/** Class that stores data on a Truck for a Frogger game.
 * The Truck is two characters wide, and will be
 * represented in the game as a > or a <, depending
 * on which way it is going.
 * 
 * Trucks are on a grid. The size of the grid is stored in the Grid class.
 * Trucks will move across the screen, one step at at time and wrap around
 * when they run out of grid.
 * 
 * @author Deborah A. Trytten
 *
 */
public class Truck 
{
	// instance data
	private int row;
	private int leftCol;
	private int rightCol;
	private char symbol;
	private boolean isRight;
	
	/** Construct a truck at this position. If right is
	 * true the truck will move to the right, otherwise
	 * it will move to the left.
	 * @param row The row the truck will be placed in.
	 * @param col The leftmost column the truck will be placed in. The truck will occupy two columns.
	 * @param isRight Whether or not the truck should face right.
	 */
	public Truck (int row, int col, boolean isRight)
	{
		this.row = row;
		leftCol = col;
		rightCol = col +1;
		this.isRight = isRight;
		
		if (isRight)
			symbol = '>';
		else
			symbol = '<';
	}
	
	/** Move the truck one column to the right or left, depending
	 * on which way the truck is facing.
	 * 
	 */
	public void move()
	{
		if (isRight)
		{
			leftCol = (leftCol + 1) % Grid.COLS;
			rightCol = (rightCol + 1) % Grid.COLS;
		}
		else
		{
			leftCol = leftCol - 1;
			if (leftCol == -1)
				leftCol = Grid.COLS -1;
			rightCol = rightCol - 1;
			if (rightCol == -1)
				rightCol = Grid.COLS-1;
		}
	}
	
	/** Return the row that contains the truck.
	 * 
	 * @return The row that contains the truck.
	 */
	public int getRow()
	{
		return row;
	}
	
	/** Return the right column for the truck.
	 * 
	 * @return The right column number.
	 */
	public int getRightCol()
	{
		return rightCol;
	}
	
	/** Return the left column for the truck.
	 * 
	 * @return The left column number.
	 */
	public int getLeftCol()
	{
		return leftCol;
	}
	
	/** Return the symbol used to represent the truck in the grid.
	 * 
	 * @return < for a truck going left and > for a truck going right.
	 */
	public char getSymbol()
	{
		return symbol;
	}
}
