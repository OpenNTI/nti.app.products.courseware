
public class Truck 
{
	// instance data
	int row;
	int leftCol;
	int rightCol;
	char symbol;
	boolean isRight;
	
	Truck (int row, int col, boolean isRight)
	{
		this.row = row;
		leftCol = col;
		rightCol = col +1;
		this.isRight = isRight;
		
		if (isRight)
			symbol = '>';
		else
			symbol = '<';
	}
	
	void move()
	{
		if (isRight)
		{
			leftCol = leftCol + 1;
			rightCol = rightCol + 1;
		}
		else
		{
			leftCol = leftCol - 1;
			rightCol = rightCol - 1;
		}
	}
}
