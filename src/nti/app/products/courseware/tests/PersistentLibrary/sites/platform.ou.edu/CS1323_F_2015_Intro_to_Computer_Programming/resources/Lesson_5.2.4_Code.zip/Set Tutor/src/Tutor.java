import java.util.Scanner;

/**  This program runs a tutor that test set operations. 
 * 
 * @author Deborah Trytten
 * @version 1.0
 *
 */
public class Tutor
{
	private int correctAnswers;
	private int wrongAnswers;
	public static final int TOTAL_EXERCISES = 10;
	
	private static final int UNION = 0;
	private static final int INTERSECTION = 1;
	private static final int SET_DIFFERENCE = 2;
	private static final int COMPLEMENT = 3; // Unary
	private static final int ELEMENT_OF = 4; // If this is modified to add additional operations, change methods
	
	/** Construct a tutor object with no right or wrong answers.
	 * 
	 */
	public Tutor()
	{
		correctAnswers = 0;
		wrongAnswers = 0;
	}

	/** The tutor will run TOTAL_EXERCISES (currently set to 10), randomly selected set problems. The
	 * correct answers will be compared to the user's answers and a tally of right and wrong answers will be
	 * kept and reported. 
	 * @param args This program has no command line arguments.
	 */
	public static void main(String[] args) 
	{
		Scanner keyboard = new Scanner(System.in);
		Tutor thisTutor = new Tutor();
		
		// Give the user TOTAL_EXERCISES
		for (int exercise = 0; exercise< TOTAL_EXERCISES; 
				++exercise)
		{
			boolean result = showAndTestRandomOperation(keyboard);
			if (result)
			{
				System.out.println("You got it right!");
				++thisTutor.correctAnswers;
				System.out.println("You have " 
						+ thisTutor.correctAnswers 
						+ " correct answers.");
			}
			else 
			{
				System.out.println("I'm sorry but you got it"
						+ " wrong.");
				++thisTutor.wrongAnswers;
				System.out.println("You have " 
						+ thisTutor.wrongAnswers 
						+ " wrong answers.");
			}
		} // end for
			
		System.out.println("You had " + thisTutor.correctAnswers + " correct answers.");
		System.out.println("You had " + thisTutor.wrongAnswers + " wrong answers.");
		
	}

	/** Show a randomly generated problem and test whether the user's answer is correct or not.
	 * 
	 * @param keyboard A Scanner for interacting with the user's keyboard.
	 * @return True if the user answered correctly or false otherwise.
	 */
	public static boolean showAndTestRandomOperation(Scanner keyboard)
	{
		Set set1 = new Set();
		Set set2 = new Set();
		Set resultSet = new Set();
		Integer element;
		String userInput;
		boolean result = false;

		// randomly choose the operation
		int operation = (int)(Math.random()*(ELEMENT_OF+1));  
		// If other operations are added, this will have to be changed.

		// randomly generate two sets--only one may be used, the element may or may not be used
		set1.createRandomSet();
		set2.createRandomSet();
		element = Set.createRandomElement();
		
		// This code would be more beautiful if it was written with a switch statement. :-), even though we don't know those officially
		if (operation == UNION)
		{
			System.out.println("Find: " + set1 + " union " + set2); // toString
			userInput = keyboard.nextLine();
			resultSet.parse(userInput);
			result = resultSet.equals(set1.union(set2));
			if (!result)
				System.out.println("The correct answer is " + set1.union(set2));
		}
		else if (operation == INTERSECTION)
		{
			System.out.println("Find: " + set1 + " intersection " + set2);
			userInput = keyboard.nextLine();
			resultSet.parse(userInput);
			result = resultSet.equals(set1.intersection(set2));
			if (!result)
				System.out.println("The correct answer is " + set1.intersection(set2));

		}
		else if (operation == SET_DIFFERENCE)
		{
			System.out.println("Find: " + set1 + " - " + set2);
			userInput = keyboard.nextLine();
			resultSet.parse(userInput);
			result = resultSet.equals(set1.setDifference(set2));
			if (!result)
				System.out.println("The correct answer is " + set1.setDifference(set2));

		}
		else if (operation == COMPLEMENT)
		{
			System.out.println("Find: " + set1 + " complement ");
			System.out.println("Remember the universal set is integers from 0 to " + Set.LIMIT + " inclusive.");
			userInput = keyboard.nextLine();
			resultSet.parse(userInput);
			result = resultSet.equals(set1.complement());
			if (!result)
				System.out.println("The correct answer is " + set1.complement());

		}
		else if (operation == ELEMENT_OF)
		{
			System.out.println("Is " + element + " in " + set1);
			boolean boolresult = keyboard.nextBoolean();
			keyboard.nextLine();
			result = (boolresult == set1.elementOf(element));
			if (!result)
			{
				System.out.println("The correct answer is " + set1.elementOf(element));
			}
		}
		else
		{
			System.out.println("Unanticipated operation");
			result = false;
		}

		return result;
	}
}
