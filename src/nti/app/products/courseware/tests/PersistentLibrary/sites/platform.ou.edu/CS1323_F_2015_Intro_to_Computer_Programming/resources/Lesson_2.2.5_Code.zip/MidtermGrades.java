/*Write a program to calculate your grade in a class
Five midterm examinations worth 100 points each
Drop the lowest examination
Others are equally weighted
Grade structure
Pass: grade 70 or over
Fail: grade below 70
*/
import java.util.Scanner;

public class MidtermGrades 
{

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		int borderlineBetweenGrades = 70;
		
		double calculatedGrade = readAndCalculateGrades(input);
		System.out.println("The average grade was " + calculatedGrade);
		
		// The -0.5 has to be used to avoid having students with
		// grades of 69.5 failing the class
		if (calculatedGrade < (borderlineBetweenGrades - 0.5))
		{
			System.out.println("I'm sorry, but you failed the class.");
		}
		else 
		{
			System.out.println("Congratulations! You passed the class.");
		}
	}

	public static double readAndCalculateGrades(Scanner keyboard)
	{
		int nextMidtermGrade;
		double calculatedGrade = 0.0;
		int lowestMidtermGrade = Integer.MAX_VALUE;
		
		int count = 1;
		while (count <= 5)
		{
			System.out.println("Enter the next grade");
			nextMidtermGrade = keyboard.nextInt();
			
			if (nextMidtermGrade < lowestMidtermGrade)
			{
				lowestMidtermGrade = nextMidtermGrade;
			}
			calculatedGrade = calculatedGrade + nextMidtermGrade;
			count = count + 1;
		}
		
		calculatedGrade = calculatedGrade - lowestMidtermGrade;
		return calculatedGrade/4.0;
	}
}
