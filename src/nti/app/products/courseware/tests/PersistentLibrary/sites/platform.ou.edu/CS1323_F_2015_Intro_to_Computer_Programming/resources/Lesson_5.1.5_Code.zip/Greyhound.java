import java.util.GregorianCalendar;

/** This class stores data about greyhounds that are avaialble
 * for adoption.
 * @author Deborah Trytten
 * @version 1.0
 *
 */
public class Greyhound 
{
	private String name; // The dog's name
	private int birthYear; // The year the dog was born, taken from ear tattoo
	private String sex; // male or female
	private YNU kidSafe; // YES if the dog is known to be good with kids, NO if the dog is known to not be good with kids, and otherwise UNKNOWN
	private YNU catSafe; // YES if the dog is known to be good with cats, NO if the dog is known to not be good with cats, and otherwise UNKNOWN
	private YNU smallDogSafe; // YES If the dog is known to be good with small dogs, NO if the dog is known to not be good with small dogs, and otherwise UNKNOWN
	
	/** Construct a greyhound object from the given data.
	 * 
	 * @param name The dog's name.
	 * @param birthYear The year the dog was born.
	 * @param sex Male or Female.
	 * @param kidSafe YES if the dog is known to be good with kids, NO if the dog is known to not be good with kids, and otherwise UNKNOWN.
	 * @param catSafe YES if the dog is known to be good with cats, NO if the dog is known to not be good with cats, and otherwise UNKNOWN
	 * @param smallDogSafe  YES if the dog is known to be good with small dogs, NO if the dog is known to not be good with small dogs, and otherwise UNKNOWN
	 */
	public Greyhound(String name, int birthYear, String sex, YNU kidSafe, YNU catSafe, YNU smallDogSafe)
	{
		this.name = name;
		this.birthYear = birthYear;
		this.sex = sex;
		this.kidSafe = kidSafe;
		this.catSafe = catSafe;
		this.smallDogSafe = smallDogSafe;
	}
	
	/** Construct a greyhound object from the given data.  The dog will recoreded as having UNKNOWN safety for kids, cats, and small dogs.
	 * 
	 * @param name The dog's name.
	 * @param birthYear The year the dog was born.
	 * @param sex Male or Female.
	 */
	public Greyhound(String name, int birthYear, String sex)
	{
		this(name, birthYear, sex, YNU.UNKNOWN, YNU.UNKNOWN, YNU.UNKNOWN);
	}
	
	/** Return the dog's name.
	 * 
	 * @return The dog's name.
	 */
	public String getName()
	{
		return name;
	}
	
	/** Return the dog's approximate age.  The age is obtained by subtracting the birthyear from the current year.
	 * This means that the age could be off by as much as one year.
	 * @return An approximate age for the dog.
	 */
	public int getAge()
	{
		GregorianCalendar today = new GregorianCalendar();
		int year = today.get(GregorianCalendar.YEAR);
		return year - birthYear;
	}
	
	/** Return the dog's sex.
	 * 
	 * @return The dog's sex.
	 */
	public String getSex()
	{
		return sex;
	}
	
	/** Return an indication of whether this dog is or is not safe with cats.
	 * 
	 * @return Return YES if the dog is safe with cats, NO if it isn't and UNKNOWN otherwise.
	 */
	public YNU getCatSafe()
	{
		return catSafe;
	}
	
	/** Return an indication of whether this dog is or is not safe with kids.
	 * 
	 * @return Return YES if the dog is safe with kids, NO if it isn't and UNKNOWN otherwise.
	 */

	public YNU getKidSafe()
	{
		return kidSafe;
	}
	
	/** Return an indication of whether this dog is or is not safe with small dogs.
	 * 
	 * @return Return YES if the dog is safe with small dogs, NO if it isn't and UNKNOWN otherwise.
	 */

	public YNU getSmallDogSafe()
	{
		return smallDogSafe;
	}
	
	/** Return a String representation of this dog.
	 * @return The dogs name, birth year, sex, and cat, kid and small dog safety status, separated by commas.
	 */
	public String toString()
	{
		return name + ", " + birthYear + ", " + sex + "," + kidSafe + ", " + catSafe + ", " + smallDogSafe;
				
	}
}
