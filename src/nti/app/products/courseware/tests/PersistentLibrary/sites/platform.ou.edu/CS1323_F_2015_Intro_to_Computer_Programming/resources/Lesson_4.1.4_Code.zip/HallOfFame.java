
import java.util.Scanner;

public class HallOfFame 
{

	public static void main(String[] args) 
	{
		final int SIZE = 5;
		
		Scanner keyboard = new Scanner(System.in);
		
		// Set up the arrays and initialize with data
		String[] winnersNames = new String[SIZE];
		int[] highScores = new int[SIZE];
		
		int index = 0;
		while (index < highScores.length)
		{
			highScores[index] = -index-1;
			winnersNames[index] = "";
			index = index + 1;
		}
		
		// Play with the user
		int games = 0;
		while (games < 10)
		{
			int score = playZork();
			System.out.println("Enter your name");
			String name = keyboard.nextLine();
			System.out.println(name + " scored " + score + " points");
			addToHallOfFame(name, score, winnersNames, highScores);
			showHallOfFame(winnersNames, highScores);
			System.out.println();
			games = games + 1;
		}

	}

	public static void showHallOfFame(String[] players, int[] highScores)
	{
		int index = 0;
		System.out.println("Hall of Fame");
		while (index < highScores.length && highScores[index] > 0)
		{
			System.out.println("" + (index + 1) + " " + players[index] 
					+ " scored " + highScores[index] + " points.");
			index = index + 1;
		}
	}
	
	public static boolean addToHallOfFame(String playerName, int score,
			 String[] players, int[] highScores)
	{
		boolean hallOfFame = false;
		
		int index = highScores.length-1;
		while (index>=0)
		{
			// Check to see if the current player belongs in the hall
			// of fame
			if (highScores[index] < score)
			{
				hallOfFame = true;
				
				// If we're not at the end of the array
				if (index < highScores.length-1)
				{
					highScores[index+1] = highScores[index];
					players[index+1] = players[index];
				}
				highScores[index] = score;
				players[index] = playerName;
			}
			index = index - 1;
		}
		
		return hallOfFame;
	}
	
	public static int playZork()
	{
		// Return a random number
		final int HIGH_SCORE = 10000;
		
		return (int)(Math.random()* HIGH_SCORE);
	}
}
