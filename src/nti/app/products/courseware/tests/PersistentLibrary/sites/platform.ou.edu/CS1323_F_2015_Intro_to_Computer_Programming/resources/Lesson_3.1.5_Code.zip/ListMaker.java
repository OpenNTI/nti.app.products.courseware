import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.io.PrintWriter;

/** A program that keeps track of a perpetual list.  The list is stored
 * to a file between runs.
 * @author Deborah Trytten
 * @version 1.0
 */
public class ListMaker 
{
	final static String FILENAME = "myCurrentList.txt";
	final static int ADD = 1;
	final static int DELETE = 2;
	final static int SHOW = 3;
	final static int EXIT = 4;

	/** Run the list making program.
	 *
	 * @param args There are no command line arguments.
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException
	{
		ArrayList<String> myList;
		myList = readListFromFile();
		
		Scanner keyboard = new Scanner(System.in);
				
		int choice = 0;
		while (choice != EXIT)
		{
			choice = selectFromMenu(keyboard);
			if (choice == ADD)
			{
				addItemToList(myList, keyboard);
			}
			else if (choice == DELETE)
			{
				deleteItemFromList(myList, keyboard);
			}
			else if (choice == SHOW)
			{
				showList(myList);
			}
		}
		
		writeListToFile(myList);
	}

	/** Delete items from the list.
	 * 
	 * @param myList The list with items.
	 * @param keyboard A Scanner setup for user interaction.
	 */
	public static void deleteItemFromList(ArrayList<String> myList, Scanner keyboard)
	{
		System.out.println("Which item number?");
		int index = keyboard.nextInt(); // Remember this was unit indexed because that's how users think
		myList.remove(index-1);
		
	}
	
	/** Add items to the list.
	 * 
	 * @param myList The list with items.
	 * @param keyboard A Scanner setup for user interaction.
	 */
	public static void addItemToList(ArrayList<String> myList, Scanner keyboard)
	{
		System.out.println("Enter item name");
		String name = keyboard.nextLine();
		System.out.println("After which item? (Enter 0 if the list is empty)");
		int index = keyboard.nextInt();
		myList.add(index, name);
	}

	/** Show the items on the list to the user by printing to the console.
	 * 
	 * @param myList The list to be shown.
	 */
	public static void showList(ArrayList<String> myList)
	{
		int count=0;
		while (count < myList.size())
		{
			System.out.println((count+1) + ". " + myList.get(count));
			count = count+1;
		}
	}
	
	/** Read the list from a default file.
	 * 
	 * @return If the default file has not previously been written, an empty list will be returned.
	 * If the file was previously written, the contents of the file will be read, one line at a time,
	 * and entered into the list.
	 * @throws FileNotFoundException
	 */
	public static ArrayList<String> readListFromFile() throws FileNotFoundException
	{
		File file = new File(FILENAME);
		ArrayList<String> result = new ArrayList<String>();
		
		if (!file.exists())
		{
			return result;
		}
		
		Scanner scanFile = new Scanner(file);
		while (scanFile.hasNextLine())
		{
			String nextLine = scanFile.nextLine();
			result.add(nextLine);
		}
		
		scanFile.close();
		return result;
		
	}
	
	/** Write the list to a default file.
	 * 
	 * @return The default file name will be opened, and items on the list will be written to the 
	 * file, one to a line.
	 * @throws FileNotFoundException
	 */
	public static void writeListToFile(ArrayList<String> list) throws FileNotFoundException
	{
		File file = new File(FILENAME);
		PrintWriter printer = new PrintWriter(file);
		
		int index = 0;
		while (index < list.size())
		{
			printer.println(list.get(index));
			index = index + 1;
		}
		
		printer.close();
	}
	
	/** Show the user a menu and allow them to make a selection.
	 * 
	 * @param input A Scanner for user interaction.
	 * @return The number of the menu item selected.
	 */
	public static int selectFromMenu(Scanner input)
	{
		int result = 0;		
		System.out.println("Please choose an action:");
		System.out.println(ADD + ". Add a new item");
		System.out.println(DELETE + ". Delete an item");
		System.out.println(SHOW + ". Show the list");
		System.out.println(EXIT + ". Exit the program");
		
		result = input.nextInt();
		input.nextLine(); // read the newline character to prevent problems later
		return result;
	}
}
