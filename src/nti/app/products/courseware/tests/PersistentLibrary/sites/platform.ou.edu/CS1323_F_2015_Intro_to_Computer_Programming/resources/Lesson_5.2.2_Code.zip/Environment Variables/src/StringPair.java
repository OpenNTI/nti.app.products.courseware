/** A class that aggregates a pair of String objects (key, value). The value
 * is designed to be retrieved from the key.
 * 
 * @author Deborah A. Trytten
 * @version 1.0
 *
 */
public class StringPair 
{
	// Instance data
	private String key;
	private String value;
	
	/** Construct a pair of Strings.
	 * 
	 * @param k The key.
	 * @param v The value.
	 */
	public StringPair(String key, String value)
	{
		this.key = key;
		this.value = value;
	}
	
	/** Return the first String, the key.
	 * 
	 * @return The key.
	 */
	public String getKey()
	{
		return key;
	}
	
	/** Return the second String, the value.
	 * 
	 * @return The value.
	 */
	public String getValue()
	{
		return value;
	}
	
	/** Determine whether the StringPair has matching keys.
	 * 
	 * @param other The other object to compare to this one.
	 * @return Return true if the implicit object and other have the same key.
	 */
	public boolean equals(StringPair other)
	{
		String otherKey = other.key;
		return this.key.equals(otherKey);
	}
	
	/** Determine the ordering of StringPair objects based on the key.
	 * 
	 * @param other The other object to compare to this one.
	 * @return The value 0 if the argument's key is equal to this object's key; 
	 * a value less than 0 if this object's key is lexicographically less than the 
	 * argument'e key; and a value greater than 0 if this object's key is 
	 * lexicographically greater than the argument's key.
	 */
	public int compareTo(StringPair other)
	{
		return this.key.compareTo(other.key);
	}
	
	/** Show the key and value as a String.
	 * 
	 * @return A String containing the key and value, with labels.
	 */
	public String toString()
	{
		return "Key: " + key + " Value: " + value;
	}
}
