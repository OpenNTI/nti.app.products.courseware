import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.io.PrintWriter;
import java.util.Collections;

public class ListMakerWithHashtags {

	/** A program that keeps track of a perpetual list.  The list is stored
	 * to a file between runs.
	 * @author Deborah Trytten
	 * @version 1.0
	 */
	final static String FILENAME = "myCurrentList.txt";
	final static int ADD = 1;
	final static int DELETE = 2;
	final static int SHOW = 3;
	final static int MOVE_UP = 4;
	final static int MOVE_DOWN = 5;
	final static int MOVE_TO_POSITION = 6;
	final static int SEARCH_BY_HASHTAG = 7;
	final static int EXIT = 8;

	/** Run the list making program.
	 *
	 * @param args There are no command line arguments.
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException
	{
		ArrayList<String> myList;
		myList = readListFromFile();
		
		Scanner keyboard = new Scanner(System.in);
				
		int choice = 0;
		while (choice != EXIT)
		{
			choice = selectFromMenu(keyboard);
			if (choice == ADD)
			{
				addItemToList(myList, keyboard);
			}
			else if (choice == DELETE)
			{
				deleteItemFromList(myList, keyboard);
			}
			else if (choice == SHOW)
			{
				showList(myList);
			}
			else if (choice == MOVE_UP)
			{
				moveUp(myList, keyboard);
			}
			else if (choice == MOVE_DOWN)
			{
				moveDown(myList, keyboard);
			}
			else if (choice == MOVE_TO_POSITION)
			{
				moveToPosition(myList, keyboard);
			}
			else if (choice == SEARCH_BY_HASHTAG)
			{
				searchByHashTag(myList, keyboard);
			}
		}
		
		writeListToFile(myList);
	}
	/** Move a selected item down one position in the list.  If the item is at the end of the
	 * list the method will do nothing.
	 * 
	 * @param list The original list. This list will be modified in the method.
	 * @param keyboard A Scanner object initialized to the console.
	 */
	public static void moveDown(ArrayList<String> list, Scanner keyboard)
	{
		System.out.println("Which item would you like to move down?");
		int index = keyboard.nextInt(); // This will be unit indexed because it is coming from the user
		index = index-1; // Change back to zero indexing
		
		// Check the range
		if (index == list.size()-1)
			return;
		
		if (index >= 0 && index < list.size()-1)
		{
			// Perform the move
			Collections.swap(list, index, index+1);
		}
		
	}
	
	/** Move a selected items up one position in the list.  If the item is at the start of the
	 * list the method will do nothing.
	 * 
	 * @param list The original list. This list will be modified in the method.
	 * @param keyboard A Scanner object initialized to the console.
	 */
	public static void moveUp(ArrayList<String> list, Scanner keyboard)
	{
		System.out.println("Which item would you like to move up?");
		int index = keyboard.nextInt(); // This will be unit indexed because it is coming from the user
		index = index-1; // Change back to zero indexing
		
		// Check the range
		if (index == 0)
			return;
		
		if (index > 0 && index < list.size())
		{
			// Perform the move
			Collections.swap(list, index, index-1);
		}

	}

	/** Move a selected item to a given position in the list.  If the selected position is 
	 * outside of the bounds of the list, the method will do nothing.
	 * 
	 * @param list The original list. This list will be modified in the method.
	 * @param keyboard A Scanner object initialized to the console.
	 */
	public static void moveToPosition(ArrayList<String> list, Scanner keyboard)
	{
		System.out.println("Which item would you like to move?");
		int sourceIndex = keyboard.nextInt(); // This will be unit indexed because it is coming from the user
		sourceIndex = sourceIndex-1; // zero indexed
		
		System.out.println("Where would you like to move it?");
		int destinationIndex = keyboard.nextInt(); // unit indexed
		destinationIndex = destinationIndex-1; // zero indexed
		
		//Check the range
		if (destinationIndex < 0 || destinationIndex > list.size()-1)
		{
			return;
		}
		
		if (sourceIndex < 0 || sourceIndex > list.size()-1)
		{
			return;
		}
		
		//Perform the move
		String element = list.get(sourceIndex);
		list.remove(sourceIndex);
		list.add(destinationIndex, element);
	}

	/** Print out all items in the list with a user selected hashtag.  Hashtags begin
	 * with a # (and contain only one #), and contain no spaces.
	 * 
	 * @param list The original list. This list is not modified in the method.
	 * @param keyboard A Scanner object initialized to the console.
	 */
	public static void searchByHashTag(ArrayList<String> list, Scanner keyboard)
	{
		System.out.println("Enter your hashtag, please include the # and don't use spaces.");
		String hashtag = keyboard.next(); // by using next, we make sure they didn't mess up the spaces
		hashtag = hashtag+" "; // Add on a space so that partial hashtags aren't found
		keyboard.nextLine(); // get rid of garbage
		
		// Check the input
		if (!hashtag.contains("#"))
		{
			System.out.println("You do not have a # in your hashtag");
			return;
		}
		
		// Perform the search
		ArrayList<String> results = new ArrayList<String>();
		
		int index = 0;
		while (index <list.size())
		{
			String listItem = list.get(index);
			listItem = listItem + " ";
			if (listItem.contains(hashtag))
			{
				results.add(listItem);
			}
			index = index + 1;
		}
		
		// Show results
		if (results.size()==0)
		{
			System.out.println("There are no matches for your hashtag");
			return;
		}
		
		index = 0;
		while (index < results.size())
		{
			System.out.println(results.get(index));
			index = index + 1;
		}
		
	}

	
	/** Delete items from the list.
	 * 
	 * @param myList The list with items.
	 * @param keyboard A Scanner setup for user interaction.
	 */
	public static void deleteItemFromList(ArrayList<String> myList, Scanner keyboard)
	{
		System.out.println("Which item number?");
		int index = keyboard.nextInt(); // Remember this was unit indexed because that's how users think
		index = index - 1; // change to zero indexed
		
		// If the index out of range, return
		if (index < 0 || index >= myList.size())
		{
			return;
		}
		myList.remove(index);
		
	}
	
	/** Add items to the list.
	 * 
	 * @param myList The list with items.
	 * @param keyboard A Scanner setup for user interaction.
	 */
	public static void addItemToList(ArrayList<String> myList, Scanner keyboard)
	{
		System.out.println("Enter item name");
		String name = keyboard.nextLine();
		System.out.println("After which item? (Enter 0 if the list is empty)");
		int index = keyboard.nextInt();
		
		// Check the validity of an index
		if (index < 0 || index > myList.size())
			return;
		
		myList.add(index, name);
	}

	/** Show the items on the list to the user by printing to the console.
	 * 
	 * @param myList The list to be shown.
	 */
	public static void showList(ArrayList<String> myList)
	{
		int count=0;
		while (count < myList.size())
		{
			System.out.println((count+1) + ". " + myList.get(count));
			count = count+1;
		}
	}
	
	/** Read the list from a default file.
	 * 
	 * @return If the default file has not previously been written, an empty list will be returned.
	 * If the file was previously written, the contents of the file will be read, one line at a time,
	 * and entered into the list.
	 * @throws FileNotFoundException
	 */
	public static ArrayList<String> readListFromFile() throws FileNotFoundException
	{
		File file = new File(FILENAME);
		ArrayList<String> result = new ArrayList<String>();
		
		if (!file.exists())
		{
			return result;
		}
		
		Scanner scanFile = new Scanner(file);
		while (scanFile.hasNextLine())
		{
			String nextLine = scanFile.nextLine();
			result.add(nextLine);
		}
		
		scanFile.close();
		return result;
		
	}
	
	/** Write the list to a default file.
	 * 
	 * @return The default file name will be opened, and items on the list will be written to the 
	 * file, one to a line.
	 * @throws FileNotFoundException
	 */
	public static void writeListToFile(ArrayList<String> list) throws FileNotFoundException
	{
		File file = new File(FILENAME);
		PrintWriter printer = new PrintWriter(file);
		
		int index = 0;
		while (index < list.size())
		{
			printer.println(list.get(index));
			index = index + 1;
		}
		
		printer.close();
	}
	
	/** Show the user a menu and allow them to make a selection.
	 * 
	 * @param input A Scanner for user interaction.
	 * @return The number of the menu item selected.
	 */
	public static int selectFromMenu(Scanner input)
	{
		int result = 0;		
		System.out.println("Please choose an action:");
		System.out.println(ADD + ". Add a new item");
		System.out.println(DELETE + ". Delete an item");
		System.out.println(SHOW + ". Show the list");
		System.out.println(MOVE_UP + ". Move an item up the list");
		System.out.println(MOVE_DOWN + ". Move an item down the list");
		System.out.println(MOVE_TO_POSITION + ". Move an item to a desired position");
		System.out.println(SEARCH_BY_HASHTAG + ". Search for all items with a given HashTag");
		System.out.println(EXIT + ". Exit the program");
		
		result = input.nextInt();
		input.nextLine(); // read the newline character to prevent problems later
		return result;
	}
}
