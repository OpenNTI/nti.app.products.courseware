import java.util.Scanner;

public class RestaurantTally 
{

	public static void main(String[] args) 
	{
		Scanner keyboard = new Scanner(System.in);
		
		// Declare accummulators and intialize to 0
		int burgerCount = 0;
		int saladCount = 0;
		int specialCount = 0;
		
		// Proming read
		System.out.println("Enter the  type (special, salad, or hamburger) of entr�e followed by the number, "
				+ "or quit to exit the program.");
		
		String food = keyboard.next();

		while (!food.equalsIgnoreCase("Quit"))
		{

			int count = keyboard.nextInt();
			
			if (food.equalsIgnoreCase("Hamburger"))
			{
				burgerCount += count;
			}
			else if (food.equalsIgnoreCase("Salad"))
			{
				saladCount += count;
			}
			else if (food.equalsIgnoreCase("Special"))
			{
				specialCount += count;
			}
			else
			{
				System.out.println("Unanticipated condition");
			}
			
			//Priming read
			System.out.println("Enter the  type (special, salad, or hamburger) of entr�e followed by the number, "
					+ "or quit to exit the program.");
			food = keyboard.next();
		}
		
		System.out.println("You sold " + burgerCount + " hamburgers, " + saladCount + " salads and " + specialCount + " specials");
		keyboard.close();
	}

}
