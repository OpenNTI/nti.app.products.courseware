import java.util.Arrays;
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;

/** This program is a word by word spelling checker.  It relies on a single dictionary. The program reads the file
 * name for the dictionary from the command line. 
 * @author Deborah A. Trytten
 *
 */
public class SpellingChecker 
{
	/** The program reads the global dictionary from a file into an array. The dictionary
	 * is assumed to be sorted.
	 * The contents of the array is then searched (using binary search) to find out
	 * whether words are spelled correctly or not. 
	 * @param args The first command line argument is the global dictionary, one word to a line,
	 * all words in lower case.  
	 * @throws FileNotFoundException If the dictionary is not found in the Project
	 * directory of eclipse.
	 */
	public static void main(String[] args) throws FileNotFoundException
	{
		// This kind of guard is always a good idea, in case people misunderstand command
		// line arguments
		if (args.length != 1)
		{
			System.out.println("Please enter the name of the global dictionary"
						+ " at the command line");
			System.exit(0); // failure
		}
		
		// The size of the global dictionary is fixed
		String[] globalDictionary = readDictionary(args[0]);
		
		processInput(globalDictionary);
	}

	/** Repeatedly allow the user to enter a word.  The word will be sought in the
	 * global dictionary.  
	 * @param global The global dictionary of words.
	 */
	public static void processInput(String[] global)
	{
		Scanner keyboard = new Scanner(System.in);
		
		String answer;
		
		// user input will terminate this loop
		while (true)
		{
			// We can't spell check quit--but that's OK.
			System.out.println("Enter a word or QUIT to stop:");
			String word = keyboard.next();
			word = word.toLowerCase(); // the dictionary is in lower case
			
			// Get out of this method if the user wants to quit
			if (word.equals("quit"))
				return;
			
			// Search the global dictionary
			if (Arrays.binarySearch(global, word) >= 0)
			{
				System.out.println("That word is spelled correctly");
			}
			else
			{
				System.out.println("That word is not spelled correctly");
			}
			
		} // end while
	
	}
	
	/** Read the dictionary file.
	 * 
	 * @param fileName The name of the file.
	 * @return  An array containing each line of the file. The array size comes from the
	 * number of lines in the file.
	 * @throws FileNotFoundException If the file is not found in the Project directory as expected.
	 */
	public static String[] readDictionary(String fileName) throws FileNotFoundException
	{
		Scanner file = new Scanner(new File(fileName));
		
		// find the length of the dictionary by reading the file
		int count = 0;
		while (file.hasNextLine())
		{
			++count;
			file.nextLine();
		}
		file.close();
		
		// Now read the file and fill the array
		String[] result = new String[count];
		
		// Reconstruct the file to read it a second time.
		file = new Scanner(new File(fileName));
		
		// Read the file again
		int index = 0;
		while (index < count)
		{
			result[index] = file.nextLine();
			++index;
		}
		file.close();
		return result;
		
	}
	
}
