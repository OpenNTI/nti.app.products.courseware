import java.util.Scanner;
import java.util.Arrays;

public class AutoCompletion 
{
	// Students may want to put these in main and pass them as parameters
	private static final int ADD = 1;
	private static final int SEARCH = 2;
	private static final int QUIT = 3;
	
	public static void main(String[] args) 
	{
		final int SIZE = 100;
		String[] emailAddresses = new String[SIZE];
		int size = 0;
		
		Scanner input = new Scanner(System.in);
		
		// Priming read
		int menu = menuChoice(input);
		while(menu != QUIT)
		{
			if (menu == ADD)
			{
				System.out.println("Enter the email address");
				String email = input.nextLine();
				size = addNewEmail(emailAddresses, size, email);
			}
			else if (menu == SEARCH)
			{
				String email = autoComplete(emailAddresses, size, input);
				if (email != null)
					System.out.println("Found: " + email);
				else
					System.out.println("No matching email was found");
			}
			else
			{
				System.out.println("Unanticipated case");
			}
			
			// priming read
			menu = menuChoice(input);

		} // end while
		
	}

	public static String autoComplete(String[] data, int size, Scanner input)
	{
		System.out.println("Enter the first letters, one at a time");
		String start = "";

		while (true)
		{
			String read = input.nextLine();
			start += read;
			
			System.out.println("DEBUG: " + start);
			
			int count=0;
			String result="";
			
			for (int i=0; i<size; ++i)
			{
				System.out.println("DEBUG: " + data[i]);
				if (data[i].startsWith(start))
				{
					result = data[i]; // keep just the last one
					System.out.println(data[i]);
					++count;
				}
				
			}
			
			if (count == 1)
				return result;
			
			if (count == 0)
				return null;
			
		}
	}
	
	public static int menuChoice(Scanner keyboard)
	{
		System.out.println("Please choose from the following menu of choices:");
		System.out.println("1. Enter a new email address");
		System.out.println("2. Find an existing email address");
		System.out.println("3. Quit.");
		System.out.println("What is your choice?");
		
		int choice = keyboard.nextInt();
		keyboard.nextLine(); // get rid of newline
		
		// Allow the user to re-enter data
		while (choice < ADD || choice > QUIT)
		{
			System.out.println("You must choose a value between 1 and 3");
			System.out.println("Please re-enter your choice");
			choice = keyboard.nextInt();
			keyboard.nextLine();
		}
		
		return choice;
	}
	
	public static int addNewEmail(String[] data, int size, String insertMe)
	{
		if (Arrays.binarySearch(data, 0, size, insertMe) > 0)
		{
			System.out.println("That email address has already been inserted");
			return size; // already in array
		}
		
		if (size == data.length)
		{
			System.out.println("Too many addresses are stored");
			return size; // the array is full already
		}
		
		// This is essentially one inner loop of insertion sort
		int index;
		for (index = size; index > 0 && data[index-1].compareTo(insertMe) > 0; --index)
		{
			data[index] = data[index-1];
		}
			
		data[index] = insertMe;
		
		return size+1;
	}
}
