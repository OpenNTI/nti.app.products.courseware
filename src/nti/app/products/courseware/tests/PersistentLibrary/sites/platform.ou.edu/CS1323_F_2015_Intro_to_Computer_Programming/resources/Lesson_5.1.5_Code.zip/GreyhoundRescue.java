import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintWriter;
/** Stores the data for a greyhound rescue.
 * 
 * @author Deborah Trytten
 *
 */
public class GreyhoundRescue 
{
	private ArrayList<Greyhound> adoptableDogs; // the adoptable dogs
	private static final String FILE_NAME = "greyhounds.txt"; // the file where the data is stored between runs
	
	/** Construct an empty greyhound rescue.
	 * 
	 */
	public GreyhoundRescue()
	{
		adoptableDogs = new ArrayList<Greyhound> ();
	}
	
	/** Read the list of dogs from the default file.
	 * 
	 * @throws FileNotFoundException If the default file has been lost.
	 */
	public void readFromFile() throws FileNotFoundException
	{
		Scanner file = new Scanner(new File(FILE_NAME));
		int size = file.nextInt();
		file.nextLine(); // get rid of newline
		
		// Read in one dog at a time
		for (int i=0; i<size; ++i)
		{
			// Read the whole line, which is comma separated
			String line = file.nextLine();
			// Split the line along the commas
			String[] words = line.split(",");
			
			//Construct the greyhound object.  The trim commands were added to remove unnecessary spaces at the ends.
			Greyhound grey = new Greyhound(words[0].trim(), Integer.parseInt(words[1].trim()), words[2].trim(), 
					YNU.valueOf(words[3].trim()), YNU.valueOf(words[4].trim()),YNU.valueOf(words[5].trim()));
			
			// Add this dog to the list of adoptable dogs
			adoptableDogs.add(grey);
		}
		
		file.close();
	}
	
	/** Write the list of adoptable dogs to the default file.
	 * 
	 * @throws FileNotFoundException If the file fails to open for any reason.
	 */
	public void writeToFile() throws FileNotFoundException
	{
		PrintWriter file = new PrintWriter(new File(FILE_NAME));
		
		// Print out the # of dogs first
		file.println(adoptableDogs.size());
		
		// Print out the dogs one at a time. The toString method in the Greyhound class creates comma separate values
		for (int i=0; i<adoptableDogs.size(); ++i)
		{
			file.println(adoptableDogs.get(i));
		}
		file.close();
	}
	
	/** Return a list of the dogs that fall in the desired age range (inclusive).
	 * 
	 * @param minimumAge The youngest dog that will be acceptable.
	 * @param maximumAge The oldest dog that will be acceptable.
	 * @return The list of all dogs that satisfy the age requirements.
	 */
	public ArrayList<Greyhound> getDogsByAge(int minimumAge, int maximumAge)
	{
		ArrayList<Greyhound> result = new ArrayList<Greyhound> ();
		
		// Step through the list of available dogs one at a time
		for (int index = 0; index < adoptableDogs.size(); ++index)
		{
			// Figure out if this dog is in the desired age range
			Greyhound hound = adoptableDogs.get(index);
			int age = hound.getAge();
			
			// If so, add it to the return list
			if (age >= minimumAge && age <= maximumAge)
			{
				result.add(hound);
			}
		}
		
		return result;
	}
	
	/** Return a list of the dogs that fall in the desired age range (inclusive), from the given list of dogs.
	 * 
	 * @param hounds The list of dogs from which the dogs in the desired age range should be chosen.
	 * @param minimumAge The youngest dog that will be acceptable.
	 * @param maximumAge The oldest dog that will be acceptable.
	 * @return The list of all dogs that satisfy the age requirements.
	 */

	public static ArrayList<Greyhound> getDogsByAge(ArrayList<Greyhound> hounds, int minimumAge, int maximumAge)
	{
		ArrayList<Greyhound> result = new ArrayList<Greyhound> ();
		
		// Step through the list of available dogs one at a time
		for (int index = 0; index < hounds.size(); ++index)
		{
			// Figure out if this dog is in the desired age range
			Greyhound hound = hounds.get(index);
			int age = hound.getAge();
			
			// If so, add it to the return list
			if (age >= minimumAge && age <= maximumAge)
			{
				result.add(hound);
			}
		}
		
		return result;
	}
	
	/** Return a list of the dogs of the desired sex.
	 * 
	 * @param sex Either male or female (not case sensitive).
	 * @return The list of all dogs that are of the chosen sex.
	 */

	public ArrayList<Greyhound> getDogsBySex(String sex)
	{
		ArrayList<Greyhound> result = new ArrayList<Greyhound> ();
		
		for (int i=0; i<adoptableDogs.size(); ++i)
		{
			Greyhound nextDog = adoptableDogs.get(i);
			if (nextDog.getSex().equalsIgnoreCase(sex))
			{
				result.add(nextDog);
			}
		}
		return result;
	}
	
	/** Return a list of the dogs that fall in the desired age range (inclusive), from the given list of dogs.
	 * 
	 * @param hounds The list of dogs from which the choices should be made.
	 * @param sex Male or female (not case sensitive).
	 * @return The list of all dogs that satisfy the sex requirements.
	 */
	public static ArrayList<Greyhound> getDogsBySex(ArrayList<Greyhound> hounds, String sex)
	{
		ArrayList<Greyhound> result = new ArrayList<Greyhound> ();
		
		for (int i=0; i<hounds.size(); ++i)
		{
			Greyhound nextDog = hounds.get(i);
			if (nextDog.getSex().equalsIgnoreCase(sex))
			{
				result.add(nextDog);
			}
		}
		return result;	
	}

	/** Return a list of the dogs that are cat safe.
	 * 
	 * @return The list of all dogs that are cat safe.
	 */

	public ArrayList<Greyhound> getCatSafeDogs()
	{
		ArrayList<Greyhound> result = new ArrayList<Greyhound> ();
		
		for (int i=0; i<adoptableDogs.size(); ++i)
		{
			Greyhound nextDog = adoptableDogs.get(i);
			if (nextDog.getCatSafe()==YNU.YES)
			{
				result.add(nextDog);
			}
		}
		return result;
	}
	
	/** Return a list of the dogs that are cat safe from the given list of dogs.
	 * 
	 * @param hounds The list of dogs from which the cat safe dogs should be chosen.
	 * @return The list of all dogs from the given list that are cat safe.
	 */
	public static ArrayList<Greyhound> getCatSafeDogs(ArrayList<Greyhound> hounds)
	{
		ArrayList<Greyhound> result = new ArrayList<Greyhound> ();
		
		for (int i=0; i<hounds.size(); ++i)
		{
			Greyhound nextDog = hounds.get(i);
			if (nextDog.getCatSafe()==YNU.YES)
			{
				result.add(nextDog);
			}
		}
		return result;	
	}
	
	/** Return a list of the dogs that are kid safe.
	 * 
	 * @return The list of all dogs that are kid safe.
	 */
	public ArrayList<Greyhound> getKidSafeDogs()
	{
		ArrayList<Greyhound> result = new ArrayList<Greyhound> ();
		
		for (int i=0; i<adoptableDogs.size(); ++i)
		{
			Greyhound nextDog = adoptableDogs.get(i);
			if (nextDog.getKidSafe()==YNU.YES)
			{
				result.add(nextDog);
			}
		}
		return result;
	}
	
	/** Return a list of the dogs that are kid safe from the given list of dogs.
	 * 
	 * @param hounds The list of dogs from which the kid safe dogs should be chosen.
	 * @return The list of all dogs from the given list that are kid safe.
	 */
	public static ArrayList<Greyhound> getKidSafeDogs(ArrayList<Greyhound> hounds)
	{
		ArrayList<Greyhound> result = new ArrayList<Greyhound> ();
		
		for (int i=0; i<hounds.size(); ++i)
		{
			Greyhound nextDog = hounds.get(i);
			if (nextDog.getKidSafe()==YNU.YES)
			{
				result.add(nextDog);
			}
		}
		return result;	
	}
	
	/** Return a list of the dogs that are small dog safe.
	 * 
	 * @return The list of all dogs that are small dog safe.
	 */
	public ArrayList<Greyhound> getSmallDogSafeDogs()
	{
		ArrayList<Greyhound> result = new ArrayList<Greyhound> ();
		
		for (int i=0; i<adoptableDogs.size(); ++i)
		{
			Greyhound nextDog = adoptableDogs.get(i);
			if (nextDog.getSmallDogSafe()==YNU.YES)
			{
				result.add(nextDog);
			}
		}
		return result;
	}
	
	/** Return a list of the dogs that are small dog safe from the given list of dogs.
	 * 
	 * @param hounds The list of dogs from which the small dog safe dogs should be chosen.
	 * @return The list of all dogs from the given list that are small dog safe.
	 */

	public static ArrayList<Greyhound> getSmallDogSafeDogs(ArrayList<Greyhound> hounds)
	{
		ArrayList<Greyhound> result = new ArrayList<Greyhound> ();
		
		for (int i=0; i<hounds.size(); ++i)
		{
			Greyhound nextDog = hounds.get(i);
			if (nextDog.getSmallDogSafe()==YNU.YES)
			{
				result.add(nextDog);
			}
		}
		return result;	
	}
}
