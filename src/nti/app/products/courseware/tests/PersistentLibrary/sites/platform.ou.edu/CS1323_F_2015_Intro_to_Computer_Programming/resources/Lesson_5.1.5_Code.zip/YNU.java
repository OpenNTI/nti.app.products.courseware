/** An enumerated type that keeps track of data that
 * is almost boolean, but could be unknown.
 * @author Deborah Trytten
 * @version 1.0
 *
 */
public enum YNU 
{
	YES, NO, UNKNOWN;
}
