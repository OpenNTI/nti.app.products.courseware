import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

/* Words With Acquaintances is a word game where players draw letters 
 * and have to use their letters in combination with letters on the board to spell words
 *
 * Players can draw wildcards that can be used to replace any 
 * single character
 * 
 * Write a program that will take a dictionary of words and use it to 
 * cheat at by systematically finding all words that contain your letters
 */
public class WordsWithAcquaintances 
{

	public static void main(String[] args) throws FileNotFoundException
	{
		String fileName = "Dictionary.txt";
		Scanner keyboard = new Scanner(System.in);
		ArrayList<String> dictionary = readDictionaryFromFile(fileName);
		
		System.out.println("Enter the characters you have without spaces.");
		String letters = keyboard.nextLine();
		System.out.println("Enter the number of wildCards");
		int wildCards = keyboard.nextInt();
		keyboard.nextLine(); // get rid of the end of line character
		
		ArrayList<String> chosenWords = findAllMatches(letters, 
				wildCards, dictionary);
		
		System.out.println(chosenWords);
	}
	
	public static int countMatches(String word, String letters)
	{
		int index = 0;
		int matches = 0;
		
		StringBuilder sbLetters = new StringBuilder(letters);
		
		//Step through the word one character at a time
		while (index < word.length())
		{
			String myChar = "" + word.charAt(index);
			
			int chosenIndex = sbLetters.indexOf(myChar);
			
			//Find if the character is in the word
			if (chosenIndex != -1)
			{
				sbLetters.deleteCharAt(chosenIndex);
				matches = matches + 1;
			}
			index = index + 1;;
		}
		return  matches;
	}

	public static ArrayList<String> findAllMatches(String letters,
			int wildCards, ArrayList<String> dictionary)
	{
		ArrayList<String> result = new ArrayList<String>();
		
		int dictionaryIndex = 0;
		while (dictionaryIndex < dictionary.size())
		{
			String word = dictionary.get(dictionaryIndex);
			int matches = countMatches(word, letters);
			
			if (matches + wildCards >= word.length())
			{
				result.add(word);
			}
			
			dictionaryIndex = dictionaryIndex + 1;
		}
				
		return result;
	}


	public static ArrayList<String> readDictionaryFromFile(String fileName)
		throws FileNotFoundException
	{
		ArrayList<String> dictionary = new ArrayList<String>();
		Scanner file = new Scanner(new File(fileName));
		
		while (file.hasNextLine())
		{
			dictionary.add(file.nextLine());
		}
		
		return dictionary;
	}

}
