import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class MyBestFriend 
{

	public static void main(String[] args) throws FileNotFoundException
	{
		String fileName = "MyTextMessages.txt";
		ArrayList<String> emails = readAddressesFromFile(fileName);
		
		String common = findCommonName(emails);
		System.out.println("The most common email was: " + common);
	}

	public static String findCommonName(ArrayList<String> addresses)
	{
		String previous= "";
		int currentCount = 1;
		int maxCount = 0;
		String maxValue = addresses.get(0);
		int index=0;
		
		while (index < addresses.size())
		{
			if (addresses.get(index).equals(previous))
			{
				currentCount = currentCount + 1;
				if (currentCount > maxCount)
				{
					maxValue = addresses.get(index);
					maxCount = currentCount;
				} // if currentCount > maxValue

			} // if addresses is previous
			else
			{
				currentCount = 0;
			} // end else
			
			previous = addresses.get(index);
			
			++index;
		} // end while
		return maxValue;
	}
	
	public static ArrayList<String> readAddressesFromFile(String fileName) 
			throws FileNotFoundException
	{
		Scanner file = new Scanner(new File(fileName));
		ArrayList<String> result = new ArrayList<String>();
		
		while (file.hasNextLine())
		{
			String name = file.nextLine();
			result.add(name);
		}
		
		file.close();
		return result;
		
	}
}
