
public class CrapsIterationTwo {

	public static void main(String[] args) 
	{
		final int WIN = 1;
		final int LOSE = 0;
		final int PLAY_AGAIN = 2;
		
		int result = PLAY_AGAIN;
		
		// Roll until you win or lose the game
		while( result == PLAY_AGAIN)
		{
			// Roll the dice
			int roll1 = generateRandomInRange(1, 6);
			System.out.println("Your first roll was " + roll1);
			int roll2 = generateRandomInRange(1, 6);
			System.out.println("Your second roll was " + roll2);

			// The logic for craps is in the determineCrapsResult method
			int roll = roll1 + roll2;
			result = determineCrapsResult(roll, WIN, LOSE, PLAY_AGAIN);
			
			// Report the result of the turn to the user
			if (result == WIN)
			{
				System.out.println("You won!");
			}
			else if (result == LOSE)
			{
				System.out.println("You lost.");
			}
			else
			{
				System.out.println("Play again");
			}
		} // end while
	} // end main program

	public static int determineCrapsResult(int roll, int win, int lose, int playAgain)
	{
		// Determine the fate of the roll		
		if (roll == 2)
		{
			return win;
		} else if (roll == 3)
		{
			return win;

		}else if (roll == 4)
		{
			return playAgain;

		}else if (roll == 5)
		{
			return playAgain;

		}else if (roll == 6)
		{
			return playAgain;

		}else if (roll == 7)
		{
			return lose;

		}else if (roll == 8)
		{
			return playAgain;

		}else if (roll == 9)
		{
			return playAgain;

		}else if (roll == 10)
		{
			return playAgain;

		}else if (roll == 11)
		{
			return lose;

		}else if (roll == 12)
		{
			return win;
		}	
		else
		{
			System.out.println("This is an unexpected case");
			return lose;
		}

	}
	
	// Generate a random number between start and end, both inclusive
	public static int generateRandomInRange(int start, int end)
	{
		return (int)(Math.random()*(end-start+1.0)) + start;

	}
	
} // end main CrapsIterationTwo
