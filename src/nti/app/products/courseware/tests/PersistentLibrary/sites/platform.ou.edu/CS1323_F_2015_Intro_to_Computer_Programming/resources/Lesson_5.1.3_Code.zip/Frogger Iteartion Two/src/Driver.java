import java.io.InputStreamReader;

/** This is a tacky ASCII version of Frogger, with some pretty
 * awkward Console input.  It's pretty annoying to play.  But it was
 * very fun to code.  The frog starts at the bottom of the screen.
 * Trucks are randomly placed, one to a lane.  This makes the game
 * incredibly easy to win, particularly since there is no time
 * limit.  The frog moved up on W, down on S, right on A and left on D.
 * The frog wins by crossing 5 lanes of traffic without getting killed.
 * The frog loses if he or she intersects with a truck.  The game
 * plays only once.
 * 
 * @author Deborah A. Trytten
 *
 */
public class Driver 
{
	final static int PAUSE_IN_MILLISECONDS = 500; // 1/2 second
	
	/** Run the Frogger game.
	 * 
	 * @param args There are no command line arguments.
	 * @throws Exception If the input from the Console is closed or
	 * the Thread fails to wake up for some reason.
	 */
	public static void main(String[] args) throws Exception
	{
		InputStreamReader input = new InputStreamReader(System.in);
	
		// Create the grids and the objects in the game
		Controller controller = new Controller();
		
		// Display before loop so the user knows where the frog/trucks are
		controller.display();
		// print out instructions
		System.out.println("Up is W, Down is S, Left is A, Right is D");

		
		// The loop will exit when the user wins or the frog dies
		// The real game also has a time limit
		while(true)
		{
			// Move frog
			controller.moveFrog(input);
			
			// See if the frog hopped out of bounds and died
			if (controller.frogOutOfBounds())
			{
				System.out.println("GAME OVER!");
				System.exit(1);
			}
			
			// See if the frog is finished and has won
			if (controller.frogWon())
			{
				controller.display(); // unsatisfying to not see goal
				System.out.println("You won!");
				System.exit(1);
			}
			
			// Check for intersections to see if frog killed by jumping  into a truck
			if (controller.frogAndTrucksCollide())
			{
				System.out.println("GAME OVER!");
				System.exit(1);
			}
			
			// Move trucks
			controller.moveTrucks();
			
			// Check for intersections to see if frog is run over by a truck
			if (controller.frogAndTrucksCollide())
			{
				System.out.println("GAME OVER!");
				System.exit(1);
			}
			
			// If the user hasn't won or lost, show the new configuration and move on
			controller.display();
			
			// print out instructions
			System.out.println("Up is W, Down is S, Left is A, Right is D");

			// Pause for one second to give user a chance
			Thread.sleep(PAUSE_IN_MILLISECONDS);
			
		} // end while
	} // end main

}
