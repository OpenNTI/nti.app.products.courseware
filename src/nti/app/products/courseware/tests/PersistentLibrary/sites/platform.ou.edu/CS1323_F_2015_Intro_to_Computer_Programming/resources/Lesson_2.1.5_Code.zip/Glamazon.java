/* Write a program to calculate the cost of a 
 * purchase for an online sale at Glamazon.com
 * Sell three items
 * Mascara at $8.99
 * Lipstick at $3.99
 * Eye shadow at $6.89
 * Taxes are 6.5%, applied before shipping
 *Shipping costs $8
 */
import java.util.Scanner;

public class Glamazon 
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in)
		;
		// Get the number of mascara, lipstick and eye shadows that are
		// purchased
		int numberMascara;
		String mascara = "mascara";
		double priceMascara = 8.99;

		int numberLipstick;
		String lipstick = "lipstick";
		double priceLipstick =3.99;
				
		int numberEyeShadow;
		String eyeShadow = "eye shadow";
		double priceEyeShadow = 6.89;
		
		double totalPrice = 0.0;
		double taxRate = 0.065;
		double shippingCost = 8.00;
		
		System.out.println(" How many " + mascara 
				+ " do you wish to purchase?");
		numberMascara = input.nextInt();

		System.out.println(" How many " + lipstick 
				+ " do you wish to purchase?");
		numberLipstick = input.nextInt();

		System.out.println(" How many " + eyeShadow 
				+ " do you wish to purchase?");
		numberEyeShadow = input.nextInt();


		// Calculate the price of the full purchase
		totalPrice = numberMascara * priceMascara 
						+numberLipstick * priceLipstick
						+ numberEyeShadow * priceEyeShadow;
		
		// Calculate the tax rate
		double tax;
		tax = totalPrice * taxRate;
		tax = tax + .005;
		tax = (int)(tax * 100)/100.0;
		
		// Add the tax to the price
		totalPrice = totalPrice + tax;
		
		// Add the shipping
		totalPrice = totalPrice + shippingCost;
		
		// Show the receipt to the consumer
		System.out.println("You ordered: " + numberMascara + " " 
				+ mascara + ".");
		System.out.println("You ordered: " + numberLipstick + " " 
				+ lipstick + ".");
		System.out.println("You ordered: " + numberEyeShadow + " " 
				+ eyeShadow + ".");
		System.out.println("Your tax was " + tax);
		System.out.println("Your shipping was " + shippingCost);
		System.out.println("The total cost of your order was " + totalPrice);


	}
}
