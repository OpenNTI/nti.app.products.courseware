import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/** Find the reading level of the given text.  The program uses the Flesch-Kincaid algorithm and a
 * heuristic for counting syllables.
 * 
 * @author Deborah Trytten
 * @version 1.0
 */
public class ReadingLevel 
{

	/** Calculate the grade level at which someone would be able to read the text. This uses
	 * U.S. grade levels (1 == about 6 years old, 12 == about 18 years old). The program
	 * will request a file name.  The file is supposed to be in plain text.
	 * @param args There are no command line arguments.
	 * @throws FileNotFoundException Thrown when the file cannot be located.
	 */
	public static void main(String[] args) throws FileNotFoundException
	{
		 Scanner keyboard = new Scanner(System.in);
		 System.out.println("Enter the name of the file");
		 String fileName = keyboard.next();
		 
		 System.out.println("The Flesch-Kincaid grade level for this work is " + findFleschKincaidIndex(fileName));
	}
	
	/* Find the Flesh Kincaid Grade Index for the data in this file.
	 * The details on the index are given here:
	 * http://en.wikipedia.org/wiki/Flesch–Kincaid_readability_tests
	 * 
	 * @param fileName The name of the file.
	 * @throws FileNotFoundException when the file cannot be opened
	 * 
	 * */
	public static int findFleschKincaidIndex(String fileName) throws FileNotFoundException
	{
		Scanner file = new Scanner(new File (fileName));
		String line;
		String[] words;
		
		int wordCount=0;
		int sentenceCount=0;
		int syllableCount=0;
		
		// read in the file and do the counting
		while (file.hasNextLine())
		{
			line = file.nextLine();
			if (!line.isEmpty())
			{
				words = line.split(" ");
				for (int index=0; index<words.length; ++index)
				{
					++wordCount;
					if (words[index].contains(".") || words[index].contains("?") || words[index].contains("!"))
						++sentenceCount;
					
					syllableCount += countSyllables(words[index]);
				}
			}
		}
		
		return 	(int) Math.round((0.39 * wordCount)/sentenceCount + (11.8 * syllableCount)/wordCount - 15.59);
	}

	/** Count the number of syllables in a word  using a heuristic.  The heuristic removes repeated
	 * vowels in the word (including y), and then counts the number that are not trailing.  
	 * Trailing ys as counted.
	 * 
	 * @param word A word that is assumed to be non-empty.
	 * @return  An approximation of the number of syllables.
	 */
	public static int countSyllables(String word)
	{
		StringBuilder sb = new StringBuilder(word);
		
		// remove consecutive vowels
		for (int i=1; i<sb.length(); ++i)
		{
			if (isVowel(sb.charAt(i)) && isVowel(sb.charAt(i-1)))
				sb.deleteCharAt(i);	
		}
		
		if (sb.length() == 0)
			return 0;
		
		// Remove trailing vowels except Y
		int lastCharacter = sb.length()-1;
		if (isVowelExceptY(sb.charAt(lastCharacter)))
			sb.deleteCharAt(lastCharacter);
		
		// Count vowels
		int count = 0;
		for (int i=0; i<sb.length(); ++i)
		{
			if (isVowel(sb.charAt(i)))
					++count;
		}
		if (count == 0)
			return 1;
		
		return count;
	}
	
	/** Return whether the given character is a vowel (a, e, i, o, u, y).
	 * 
	 * @param c A character.
	 * @return True if the character is a vowel or false otherwise.
	 */
	public static boolean isVowel(char c)
	{
		if (c=='a' || c=='e' || c == 'i' || c == 'o' || c == 'u' || c == 'y')
			return true;
		return false;
	}
	
	/** Returns whether the given character is a vowel (a, e, i, o, u).
	 * 
	 * @param c A character.
	 * @return True if the character is a vowel or false otherwise.
	 */
	public static boolean isVowelExceptY(char c)
	{
		return isVowel(c) && c != 'y';
	}
}
