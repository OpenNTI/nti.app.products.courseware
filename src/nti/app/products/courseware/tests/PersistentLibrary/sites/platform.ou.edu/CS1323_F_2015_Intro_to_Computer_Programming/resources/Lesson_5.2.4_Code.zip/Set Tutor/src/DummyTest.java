
public class DummyTest {

	public static void main(String[] args) 
	{
		Set set1 = new Set();
		
		set1.parse("{1, 1, 1, 3, 3, 3, 5, 5, 5, 5}");
		
		Set set2 = new Set();
		set2.parse("{}");
		
		boolean result = set1.equals(set2);
		System.out.println(result);
	}

}
