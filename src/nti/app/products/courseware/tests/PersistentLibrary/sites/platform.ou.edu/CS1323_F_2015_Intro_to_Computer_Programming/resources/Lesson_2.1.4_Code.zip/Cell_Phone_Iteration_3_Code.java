import java.util.Scanner;
public class CellPhone 
{


	public static void main(String[] args) 
	{
		Scanner keyboard = new Scanner(System.in);
		
		// We decided to store money in pennies because pennies are indivisble
		int planMinutes = 500;
		int monthlyCostPennies = 3999;
		int additionalMinutesPennies = 5;
		
		String planName = "Super Saver";
		
		// Get input from the user
		int talkMinutes;
		System.out.println("Enter the number of minutes you talk each month");
		talkMinutes = keyboard.nextInt();
		int totalCostPennies;
	
		//Calculate the total cost
		totalCostPennies = monthlyCostPennies 
				+ additionalMinutesPennies * (talkMinutes - planMinutes);

		System.out.println("The total cost for the " + planName + " is $" 
				+ totalCostPennies/100.0);
		
		monthlyCostPennies = 5999;
		additionalMinutesPennies = 3;
		planMinutes = 1000;
		planName = "Big Talker";
		
		//Calculate the total cost
		totalCostPennies = monthlyCostPennies 
				+ additionalMinutesPennies * (talkMinutes - planMinutes);

		System.out.println("The total cost for the " + planName + " is $" 
				+ totalCostPennies/100.0);
	}

}
