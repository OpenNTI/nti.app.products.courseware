
public class Frog 
{
	 //  instance data
	int row;
	int col;
	
	// class data
	static final char SYMBOL = '*';
	
	Frog(int r, int c)
	{
		row = r;
		col = c;
	}
	
	void moveLeft()
	{
		col = col - 1;
	}
	
	void moveRight()
	{
		col = col + 1;
	}
	
	void moveUp()
	{
		row = row - 1;
	}
	
	void moveDown()
	{
		row = row + 1;
	}
	
	public static void main(String[] args)
	{
		Frog frog = new Frog(10, 10);
		
		System.out.println("The frog started at 10, 10");
		int count = 0;
		while (count < 10)
		{
			double rand = Math.random();
			if (rand < .25)
			{
				frog.moveRight();
				System.out.println("Right: " + frog.row + ", " + frog.col);
			}
			else if (rand < .50)
			{
				frog.moveLeft();
				System.out.println("Left: " + frog.row + ", " + frog.col);
			}
			else if (rand < .75)
			{
				frog.moveUp();
				System.out.println("Up: " + frog.row + ", " + frog.col);
			}
			else
			{
				frog.moveDown();
				System.out.println("Down: " + frog.row+ ", " + frog.col);
			}
			count = count + 1;
		}
	}
}
