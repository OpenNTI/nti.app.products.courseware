import java.util.GregorianCalendar;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class PredictWeather 
{
	public static final String FILE_NAME = "Weather.csv";
	public static final int DAYS_IN_YEAR = 365; // ignore leap years
	public static final boolean TESTING = true; // if we are entering data manually
	
	/** Predict tomorrow's temperature based on the average temperature
	 * of the week surrounding
	 * @param args
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException
	{
		int dayNumber;
		
		if (TESTING)
		{
			dayNumber = getDaysNumber(); // unit indexed
			dayNumber = dayNumber - 1;
		}
		else
		{
			GregorianCalendar today = new GregorianCalendar(); // default time, locale, time zone
			dayNumber = today.get(GregorianCalendar.DAY_OF_YEAR); // unit indexed
			dayNumber = dayNumber - 1; // now zero indexed
		}
		
		int[] meanTemperature = new int[DAYS_IN_YEAR];		
		getTemperatureFromFile(meanTemperature);
		
		System.out.println("I predict tomorrow's temperature will be " + getAverageSameWeek(meanTemperature, dayNumber));
	}
	
	/** Allow the user to enter a day number at the command line.  This is used for
	 * testing the program.
	 * @return The day number entered by the user.
	 */
	public static int getDaysNumber()
	{
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("Enter the day number (unit indexed Jan 1 = 1, Dec 31 = 365)");
		return keyboard.nextInt();
	}

	/** Find the average temperature from the same week last year.
	 * 
	 * @param meanTemperature The mean temperatures for every day last year.
	 * @param dayIndex The day number in the year (January 1 = 0, January 2 = 1, etc.).
	 * @return The mean value in the array from indices dayIndex to dayIndex+7.
	 */
	public static double getAverageSameWeek(int[] meanTemperature, int dayIndex)
	{
		int index = dayIndex-3;
		int count = 0;
		int sum = 0;
		while (index <= dayIndex + 3) // one week
		{
			if ((index >= 0) && (index < DAYS_IN_YEAR))
			{
				sum = sum + meanTemperature[index];
				count = count + 1;
			}
			
			index = index + 1;
		}
		return sum/(double)count;
	}
	
	/** Read in the temperature data from last year. The file is stored in CSV format and
	 * comes from http://wunderground.com and should be stored in a file with a name determined
	 * by the constant FILE_NAME.
	 * @param meanTemperature The mean temperature data for the previous year.
	 * @throws FileNotFoundException
	 */
	public static void getTemperatureFromFile(int[] meanTemperature) throws FileNotFoundException
	{
		Scanner file = new Scanner(new File(FILE_NAME));
		
		int index = 0;
		
		//Read in header
		file.nextLine(); // skip over header
		
		while (index < DAYS_IN_YEAR)
		{
			String line = file.nextLine();
			String[] fields = line.split(",");
			meanTemperature[index] = Integer.parseInt(fields[2]);
			
			index = index + 1;
		}
	}
}
