/** A frog object for the Frogger game. The frog has a position
 * on a two dimensional board. Then dimensions of the board are set
 * in the Grid class.
 * 
 * The frog is represented on the board by the asterisk.
 * 
 * The frog starts at the bottom of the board in the middle of the game.
 * 
 * @author Deborah A. Trytten
 *
 */
public class Frog 
{
	 //  instance data
	private int row;
	private int col;
	
	// class data
	public static final char SYMBOL = '*';
	
	/** Build a new frog that starts at the given coordinates.
	 * @param r The row for the frog.
	 * @param c The column for the frog.
	 */
	public Frog(int r, int c)
	{
		row = r;
		col = c;
	}
	
	/** Return the row location of the frog.
	 * 
	 */
	public int getRow()
	{
		return row;
	}
	
	/** Return the column location of the frog.
	 * 
	 */
	public int getCol()
	{
		return col;
	}
	
	/** Move the frog one position to the right.
	 */
	public void moveLeft()
	{
		col = col - 1;
	}
	
	/** Move the frog one position to the left.
	 */
	public void moveRight()
	{
		col = col + 1;
	}
	
	/** Move the frog one position up.
	 */
	public void moveUp()
	{
		row = row - 1;
	}
	
	/** Move the frog one position down.
	 * 
	 */
	public void moveDown()
	{
		row = row + 1;
	}
	
	/** Display the row and column for the frog.
	 * 
	 */
	public String toString()
	{
		return "Frog: Row: " + row + " Col: " + col;
	}
	
	/** This is a simple test program to make sure our frog is working
	 * properly.
	 * @param args This program takes no command line arguments.
	 */
	public static void main(String[] args)
	{
		Frog frog = new Frog(10, 10);
		
		System.out.println("The frog started at 10, 10");
		int count = 0;
		while (count < 10)
		{
			double rand = Math.random();
			if (rand < .25)
			{
				frog.moveRight();
				System.out.println("Right: " + frog.row + ", " + frog.col);
			}
			else if (rand < .50)
			{
				frog.moveLeft();
				System.out.println("Left: " + frog.row + ", " + frog.col);
			}
			else if (rand < .75)
			{
				frog.moveUp();
				System.out.println("Up: " + frog.row + ", " + frog.col);
			}
			else
			{
				frog.moveDown();
				System.out.println("Down: " + frog.row+ ", " + frog.col);
			}
			count = count + 1;
		}
	}
}
