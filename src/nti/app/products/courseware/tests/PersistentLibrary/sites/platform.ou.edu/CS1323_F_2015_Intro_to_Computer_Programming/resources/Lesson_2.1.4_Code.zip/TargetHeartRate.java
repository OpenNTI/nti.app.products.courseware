import java.util.Scanner;

public class TargetHeartRate 
{

	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		
		//Get user's name and age
		String name;
		int age;
		
		System.out.println("Enter your age");
		age = keyboard.nextInt();
		keyboard.nextLine();
		
		System.out.println("Enter your name");
		name = keyboard.nextLine();
				
		// Calculate the user's heart rate minimum and maximum
		final int CRAZY_CONSTANT = 220;
		final double LOW_PERCENT = 0.65;
		final double HIGH_PERCENT = 0.85;
		
		int value = CRAZY_CONSTANT - age;
		
		double lowHeartRate = value * LOW_PERCENT;
		double highHeartRate = value * HIGH_PERCENT;
		
		final double TEN_SECONDS = 10.0 / 60.0;
		
		int tenSecondLow = (int)(lowHeartRate * TEN_SECONDS + 0.5);
		int tenSecondHigh = (int)(highHeartRate * TEN_SECONDS + 0.5);
		
		System.out.println("Your heart should beat between " + tenSecondLow + " and " + tenSecondHigh + " times in ten seconds.");
		
		// Show the target heart rates to the user
	}
}
