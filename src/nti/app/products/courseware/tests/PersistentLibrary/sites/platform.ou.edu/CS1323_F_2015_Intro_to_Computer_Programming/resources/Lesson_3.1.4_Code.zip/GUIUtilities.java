import javax.swing.JOptionPane;

/** A class of utility methods that wrap a JOptionPane and provide
 * easy access to int, double, String, and boolean types.
 * 
 * @author Deborah Trytten
 * @version 1.0
 */
public class GUIUtilities {

	/** Create an input dialog with the given prompt that returns an int value. If the
	 * user makes a mistake in data entry, like entering a double instead of an int,
	 * the method will break.
	 * 
	 * @param prompt The instructions to the user.
	 * @return The int value the user enters. 
	 */
	public static int getIntDialog(String prompt)
	{
		String resultString = JOptionPane.showInputDialog(prompt);
		int result = Integer.parseInt(resultString);
		return result;
	}
	
	/** Create an input dialog with the given prompt that returns an double value. If the
	 * user makes a mistake in data entry, like entering an int instead of a double,
	 * the method will break.
	 * 
	 * @param prompt The instructions to the user.
	 * @return The double value the user enters. 
	 */
	public static double getDoubleDialog(String prompt)
	{
		String resultString = JOptionPane.showInputDialog(prompt);
		double result = Double.parseDouble(resultString);
		return result;
	}
	
	/** Create an input dialog with the given prompt that returns a String. 
	 * 
	 * @param prompt The instructions to the user.
	 * @return The value the user enters. 
	 */
	public static String getStringDialog(String prompt)
	{
		return JOptionPane.showInputDialog(prompt);
	}
	
	/** Create an input dialog with the given prompt that returns an boolean value. If the
	 * user makes a mistake in data entry, like entering a double instead of an boolean,
	 * the method will break.
	 * 
	 * @param prompt The instructions to the user.
	 * @return The boolean value the user enters. The method will accept "true" or "True" 
	 * as legal true values.  Any other value will return false, including " true".
	 */
	public static boolean getBooleanDialog(String prompt)
	{
		String resultString = JOptionPane.showInputDialog(prompt);
		boolean result = Boolean.parseBoolean(resultString);
		return result;	
	}
	
}
