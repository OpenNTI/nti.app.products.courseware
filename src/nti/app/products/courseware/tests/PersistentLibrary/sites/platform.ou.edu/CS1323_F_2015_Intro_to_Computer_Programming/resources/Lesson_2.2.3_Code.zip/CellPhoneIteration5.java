import java.util.Scanner;

/* Suppose you want to compare the cost of several cell phone plans with ATV Telecommunications
 * Each plan has the same basic design.
 * A flat charge gives a fixed quota of minutes a month
 * Additional minutes are charged individually above the quota
 * Let’s write a program that compares 5 plans
*/

public class CellPhoneIteration5 
{

	public static void main(String[] args) 
	{
		Scanner keyboard = new Scanner(System.in);
		
		// We decided to store money in pennies because pennies are indivisible
		int planMinutes=0;
		int monthlyCostPennies=0;
		int additionalMinutesPennies=0;
		
		String planName ="";
		
		// Get input from the user
		int talkMinutes=0;
		System.out.println("Enter the number of minutes you talk each month");
		talkMinutes = keyboard.nextInt();
		keyboard.nextLine(); // read in the newline at the end of integer
		if (talkMinutes < 0)
		{
			System.out.println("Negative minutes for talk does not make sense.");
			System.out.println("Enter the number of minutes you talk each month");
			talkMinutes = keyboard.nextInt();
			keyboard.nextLine(); // read in the newline at the end of the integer
		}
		
		double smallestCostPlanPennies = 1000000000.0;// an arbitrary big number
		String cheapestPlanName = "";
		
		// Read in variables from command line
		System.out.println("Enter your plan name, or END to get the results");
		planName = keyboard.nextLine();
		
		if (!planName.equalsIgnoreCase("END"))
		{
			System.out.println("Enter the monthly cost");
			monthlyCostPennies = (int) (keyboard.nextDouble() * 100.0 + 0.5);
			keyboard.nextLine();
			
			System.out.println ("Enter the plan minutes");
			planMinutes = keyboard.nextInt();
			keyboard.nextLine();
			
			System.out.println("Enter the additional minute cost");
			additionalMinutesPennies = (int) (keyboard.nextDouble() * 100.0 + 0.5);
			keyboard.nextLine();
		}

		while (!planName.equalsIgnoreCase("END"))
		{
			
			int totalCostPennies;
		
			//Calculate the total cost
			if (talkMinutes > planMinutes)
			{
				totalCostPennies = monthlyCostPennies 
						+ additionalMinutesPennies * (talkMinutes - planMinutes);
			} // end if talkMinutes
			else
			{
				totalCostPennies = monthlyCostPennies;
			} // end else (from if talkMinutes)
			
			System.out.println("The total cost for the " + planName + " is $" 
					+ totalCostPennies/100.0);
			
			if (totalCostPennies < smallestCostPlanPennies)
			{
				smallestCostPlanPennies =totalCostPennies;
				cheapestPlanName = planName;			
			}
			
			// Read in variables from command line
			System.out.println("Enter your plan name or END to exit the program");
			planName = keyboard.nextLine();
			
			//Priming read
			if (!planName.equalsIgnoreCase("END"))
			{
				System.out.println("Enter the monthly cost");
				monthlyCostPennies = (int) (keyboard.nextDouble() * 100.0 + 0.5);
				keyboard.nextLine();
				
				System.out.println ("Enter the plan minutes");
				planMinutes = keyboard.nextInt();
				keyboard.nextLine();
				
				System.out.println("Enter the additional minute cost");
				additionalMinutesPennies = (int) (keyboard.nextDouble() * 100.0 + 0.5);
				keyboard.nextLine();
			}
			
		}// end while
		
		System.out.println("The cheapest plan was " + cheapestPlanName);
		System.out.println("The cheapest cost was " + smallestCostPlanPennies/100.0);

	}

}
