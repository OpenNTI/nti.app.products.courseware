
public class TestGuiUtilities 
{
	public static void main(String[] args)
	{
		System.out.println(GUIUtilities.getBooleanDialog("Enter a Boolean"));
		
		System.out.println(GUIUtilities.getIntDialog("Enter an integer"));

		System.out.println(GUIUtilities.getDoubleDialog("Enter a Double"));

		System.out.println(GUIUtilities.getStringDialog("Enter a String"));

	}
}
