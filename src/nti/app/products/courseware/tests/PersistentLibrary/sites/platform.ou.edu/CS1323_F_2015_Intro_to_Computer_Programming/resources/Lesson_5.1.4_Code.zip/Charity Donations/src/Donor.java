import java.util.ArrayList;

/** A class that stores the data for one donor to a charity.
 * 
 * @author Deborah A. Trytten
 *
 */
public class Donor 
{
	private String name;
	private Address address;
	private ArrayList<Donation> donations;
	
	/** Construct a donor object with the given name and address.
	 * 
	 * @param name The donor's name.
	 * @param address The donor's address.
	 */
	public Donor(String name, Address address)
	{
		this.name = name;
		this.address = address;
		
		donations = new ArrayList<Donation>();
	}

	/** Return the donor's name.
	 * 
	 * @return The donor's name.
	 */
	public String getName()
	{
		return name;
	}
	
	/** Return the donor's address.
	 * 
	 * @return The donor's address.
	 */
	public Address getAddress()
	{
		return address;
	}
	
	/** Return the value of all donations made by this donor. This includes
	 * cash and donated items.
	 * @return The monetary value of all donations made by this donor.
	 */
	public double getValueOfAllDonations()
	{
		double cost = 0.0;
		
		// step through all donations made by the person and add up
		// both the money and the cost of the donated items
		for(Donation d: donations)
		{
			cost = cost + d.getMoney();
			ArrayList<DonatedItem> list = d.getDonatedItems();
			for (DonatedItem i: list)
			{
				cost = cost + i.getItemPrice();
			}
		}
		
		return cost;
	}
	
	/** Add another donation for this donor.
	 * 
	 * @param d The donation (that can include cash and items donated) this donor just made.
	 */
	public void addDonation(Donation d)
	{
		donations.add(d);
	}
}
