import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/** This class simulates environment variables in Unix.
 * 
 * @author Deborah A. Trytten
 *
 */
public class Driver 
{

	/** Read the environment variables from a file.  The file name is the first
	 * command line argument.
	 * @param args The file name.
	 * @throws FileNotFoundException If a file by that name is not found in the Project home directory.
	 */
	public static void main(String[] args) throws FileNotFoundException
	{
		Dictionary environment = new Dictionary();
		Scanner keyboard = new Scanner(System.in);
		
		// Read in the file
		if (args.length == 0)
		{
			System.out.println("No configuration file was found");
		}
		else
		{
			String fileName = args[0];
			readFile(fileName, environment);
		}
		
		while (true) // infinite loop on purpose
		{
			System.out.println("Enter variable name to see environment variable, variable=value to add a new one or QUIT to exit");
			String line = keyboard.nextLine();
			
			if (line.equalsIgnoreCase("quit"))
				System.exit(0); // the 0 means everything is OK
			else if (line.contains("=")) 
				addToDictionary(line, environment);
			else
				// Search
				System.out.println(environment.getValue(line));
		}
	}
	
	/** Add data to the environment variables.  The line should be of the form variable=value. If it
	 * is not, nothing is added.
	 * @param line A String containing a variable name, an equals, and a value. 
	 * @param env The environment variable data structure.
	 */
	public static void addToDictionary(String line, Dictionary env)
	{
		int indexEquals = line.indexOf("=");
		// If there is no = sign, there is no key, value pair. Add nothing to the dictionary
		
		if (indexEquals == -1) 
			return;
		
		String key = line.substring(0, indexEquals);
		String value = line.substring(indexEquals+1, line.length());
		
		env.put(key, value);
	}
	
	/** Read in command line arguments from a file.  The format is variable=value, one environment
	 * variable to a line.
	 * @param fileName The name of the file that contains the environment variables.
	 * @param env The environment variable data structure.
	 * @throws FileNotFoundException If the file is not located in the project home directory.
	 */
	public static void readFile(String fileName, Dictionary env) throws FileNotFoundException
	{
		Scanner file = new Scanner(new File(fileName));
		
		while (file.hasNextLine())
		{
			String line = file.nextLine();
			addToDictionary(line, env);
		}
		
		file.close();
	}


}
