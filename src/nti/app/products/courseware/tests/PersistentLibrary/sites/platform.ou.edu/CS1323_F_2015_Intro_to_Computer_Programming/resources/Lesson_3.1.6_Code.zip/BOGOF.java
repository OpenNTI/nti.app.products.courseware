import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class BOGOF 
{

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		ArrayList<Double> sales;
		
		sales = getUserData(input);
		double cost = findCost(sales);
		
		System.out.println("The cost of your purchases is " + cost);
	}

	public static ArrayList<Double> getUserData(Scanner keyboard)
	{
		ArrayList<Double> result = new ArrayList<Double> ();
		
		// Priming Read
		System.out.println("Enter the cost of your next purchase, or -1 to stop");
		double cost = keyboard.nextDouble();
		while (cost > 0)
		{
			result.add(cost);
		
			// Priming Read
			System.out.println("Enter the cost of your next purchase, or -1 to stop");
			cost = keyboard.nextDouble();
		}
		
		return result;
	}
	
	public static double findCost(ArrayList<Double> purchases)
	{
		Collections.sort(purchases);
		
		double cost = 0.0;
		int index = purchases.size()-1;
		while (index >= 0)
		{
			cost = cost + purchases.get(index);
			index = index - 2;
		}
		return cost;
	}
}
