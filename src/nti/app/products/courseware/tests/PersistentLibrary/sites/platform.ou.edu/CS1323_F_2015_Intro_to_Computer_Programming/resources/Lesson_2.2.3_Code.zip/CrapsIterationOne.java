/** Write a program to play a modified version of craps
 * The user rolls two six sided dice
 * Loses if the sum of the digits is 7 or 11 (craps)
 * Wins if the sum of the digits is 2, 3 or 12
 * Rolls again if the sum of the digits is 4, 5, 6, 8, 9, or 10, 12
*/

public class CrapsIterationOne 
{

	public static void main(String[] args) 
	{
		// Roll until you win or lose the game
		while(true)
		{
			// Roll the dice
			
			int roll1 = (int)(Math.random()*6.0) + 1;
			System.out.println("Your first roll was " + roll1);
			int roll2 = (int)(Math.random()*6.0) + 1;
			System.out.println("Your second roll was " + roll2);

			int roll = roll1 + roll2;
			// Determine the fate of the roll		
			if (roll == 2)
			{
				System.out.println("You won!");
				return;
			} else if (roll == 3)
			{
				System.out.println("You won!");
				return;

			}else if (roll == 4)
			{
				System.out.println("Roll again");

			}else if (roll == 5)
			{
				System.out.println("Roll again");

			}else if (roll == 6)
			{
				System.out.println("Roll again");

			}else if (roll == 7)
			{
				System.out.println("You lost!");
				return;

			}else if (roll == 8)
			{
				System.out.println("Roll again");

			}else if (roll == 9)
			{
				System.out.println("Roll again");

			}else if (roll == 10)
			{
				System.out.println("Roll again");

			}else if (roll == 11)
			{
				System.out.println("You lost!");
				return;

			}else if (roll == 12)
			{
				System.out.println("You won!");
				return;
			}
			
		} // end while
	} // end main
} // end CrapsIterationOne
