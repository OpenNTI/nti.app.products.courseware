import  java.io.InputStreamReader;
import java.io.IOException;

/** This is the class that contains the logic of the Frogger game.  While
 * the other classes are quite independent, this class touches each of them.
 * The class contains a frog, five trucks, and a grid for displaying the data.
 * 
 * @author Deborah A. Trytten
 *
 */
public class Controller 
{

	// instance data
	private Grid grid;
	private Frog frog;
	private Truck[] trucks; 
	private static int LARGER_THAN_CONSOLE_SIZE = 20;

	/** Construct all of the game objects. Place the frog at the
	 * bottom center of the game board, and the trucks randomly, one
	 * to a line.
	 * 
	 */
	public Controller()
	{
		grid = new Grid();
		frog = new Frog(Grid.ROWS-1, Grid.COLS/2);
		trucks = new Truck[Grid.ROWS-2];
	
		// Place the trucks randomly
		for (int i=0; i<trucks.length; ++i)
		{
			boolean isRight = (Math.random() < 0.50);
			trucks[i] = new Truck(i+1,(int)(Math.random()*Grid.COLS), isRight);
		}

	}
	
	/** Move the trucks going right to the right, and the
	 * trucks going left to the left.
	 * 
	 */
	public void moveTrucks()
	{
		for (int i=0; i<trucks.length; ++i)
		{
			Truck truck = trucks[i];
			truck.move();
		}
	}
	
	/** See if the frog has passed all lanes of traffic and won
	 * the game.
	 * @return True if the frog has won and false otherwise.
	 */
	public boolean frogWon()
	{
		if (frog.getRow() == 0)
			return true;
		return false;
	}
	
	/** Determine if the frog has ventured out of bounds or not.
	 * 
	 * @return True if the frog is out of bounds and false otherwise.
	 */
	public boolean frogOutOfBounds()
	{
		return (frog.getRow() < 0 || frog.getRow() >= Grid.ROWS ||
				frog.getCol() < 0 || frog.getCol() >= Grid.COLS);
	}
	
	/** Move the frog one place to the left, right, up, or down
	 * based on user input.  The class could not use a Scanner
	 * object because Scanners block the input stream--in other 
	 * words, a Scanner would stall the game. The user enters  W
	 * to go up, A to go left, S to go down, and D to go right.
	 * 
	 * @param input Attached to the keyboard for user input.
	 * @throws IOException If the input stream becomes unreadable.
	 */
	public void moveFrog(InputStreamReader input) throws IOException
	{

		if (input.ready())  // the user has entered something
		{
			char letter = (char) input.read();
			
			// Move the frog
			if (letter=='W' || letter== 'w')
				frog.moveUp();
			else if (letter == 'A' || letter == 'a')
				frog.moveLeft();
			else if (letter == 'S' || letter == 's')
				frog.moveDown();
			else if (letter == 'D' || letter == 'd')
				frog.moveRight();
			
			// Read any other input, so the user doesn't get ahead of themselves
			while (input.ready())
				input.read(); 
		}
	}
	
	/** Use a bunch of printlines to give the illusion that the screen
	 * is really being cleared.  This illusion is not entirely successful
	 * because user input will sometimes make the board go up one line.
	 * This is why console games are tacky.
	 */
	public void clearScreen()
	{
		for (int i=0; i<LARGER_THAN_CONSOLE_SIZE; ++i)
			System.out.println();
	}
	
	/** Display the current state of the game.  First the
	 * screen is cleared, then the grid that stores the location
	 * of all objects is cleared.  The objects current locations
	 * are then drawn into the grid and the grid is written to the
	 * console, followed by the instructions for play.
	 * 
	 * This game does jump up and down a bit, and this
	 * could be avoided if playing outside of eclipse on either a 
	 * PC or Mac.  Inside of eclipse there is no clear screen
	 * mechanism available.
	 */
	public void display()
	{
		// clear the screen
		this.clearScreen();
		
		// empty the grid
		grid.clearGrid();
		
		// Put frog and trucks in grid
		
		grid.setGrid(frog.getRow(), frog.getCol(), Frog.SYMBOL);
		for(int i=0; i < trucks.length; ++i)
		{
			grid.setGrid(trucks[i].getRow(), trucks[i].getLeftCol(), trucks[i].getSymbol());
			grid.setGrid(trucks[i].getRow(), trucks[i].getRightCol(), trucks[i].getSymbol());

		}
		
		// show the grid on the screen
		grid.displayGrid();
	}
	
	/** Determine if the frog has intersected with any trucks.  Trucks kill
	 * frogs.
	 * @return True if the frog is deceased, false otherwise.
	 */
	public boolean frogAndTrucksCollide ()
	{
		for (int i=0; i<trucks.length; ++i)
		{
			if (frog.getRow() == trucks[i].getRow() && (frog.getCol()==trucks[i].getRightCol() ||
						frog.getCol() == trucks[i].getLeftCol()))
				return true;
		}
		return false;
	}
	
}

