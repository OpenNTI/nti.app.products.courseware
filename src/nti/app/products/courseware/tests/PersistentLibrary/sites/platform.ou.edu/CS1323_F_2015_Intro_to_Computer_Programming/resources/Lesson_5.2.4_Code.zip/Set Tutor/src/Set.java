import java.util.ArrayList;

/** A Set of integers.  Sets are stored as ArrayList<Integer> with no repeating values. The 
 * universal set goes from 0 to 10 (controlled by a public constant called LIMIT).
 * 
 * @author Deborah Trytten
 *
 */
public class Set 
{
	/** The universal set goes from 0 to LIMIT (inclusive).
	 * 
	 */
	public static final int LIMIT = 10; // the sets will be made up of integers from 0 (inclusive) to 20 (inclusive)
	
	// The elements of the set are stored in this ArrayList.  Duplicate elements should not be stored.
	private ArrayList<Integer> elements;
	
	/** Construct an empty set.
	 * 
	 */
	public Set()
	{
		elements = new ArrayList<Integer>();
	}
	
	/** Construct a set from the data in the given array. If any of the elements are outside of the universal set,
	 * they will be ignored. Duplicate values are also not added to the set.
	 * 
	 * @param data An array containing int values that are added to the set.
	 */
	public Set(int[] data)
	{
		elements = new ArrayList<Integer>(data.length); // when you know the size, you should use it
		
		// Add the data in one element at a time.
		for (int i=0; i<data.length; ++i)
		{
			// Make sure that the data is in range.
			if (data[i] >= 0 && data[i] <= LIMIT)
				elements.add(data[i]);
		}
		
		removeDuplicates();
	}
	
	/** Construct a copy of an existing set).
	 * 
	 * @param oldSet A set to be copied. 
	 */
	public Set(Set oldSet)
	{
		// don't do this
		// elements = oldSet.elements;  // WRONG WRONG WRONG
		elements = new ArrayList<Integer>(oldSet.elements.size());
		
		elements.addAll(oldSet.elements);
	}
	
	/** Remove all duplicate values from the set.  This enforces a property that we have used
	 * widely in many of the methods--duplicate elements are not permitted.
	 */
	private void removeDuplicates()
	{
		for (int item = 0; item <elements.size(); ++item)
		{
			// Make sure that this item is not equivalent to the other items
			for (int test = item+1; test<elements.size(); ++test)
			{
				if (elements.get(item) == elements.get(test))
				{
					// we found a duplicate
					elements.remove(test);
					test = item;
				}
			}// end for test
		} // end for item
	}
	
	/** Initialize this set to a randomly selected set.
	 * 
	 */
	public void createRandomSet()
	{
		// This set will have <= this number of elements
		int numElements = (int) (Math.random() * (LIMIT+1));
		elements = new ArrayList<Integer>(numElements);  // set the initial capacity
		
		for (int i=0; i<numElements; ++i)
		{
			elements.add((int) (Math.random()*(LIMIT+1)));
		}
		
		// We could have checked to see that each value was in the set before adding them too
		removeDuplicates();
	}
	
	/** Initialize this set to a randomly selected set of the given size. 
	 * If size is larger than LIMIT + 1, the universal set will be returned.
	 * @param size
	 */
	public void createRandomSet(int size)
	{	
		// Get rid of any strays that might have been hanging around
		elements.clear();
		
		// If the user asks for more than is possible, give them all you have
		if (size >= LIMIT)
		{
			for (int i=0; i<LIMIT; ++i)
			{
				elements.add(i);
			}
		}
		
		int currentSize = 0;
		while (currentSize < size)
		{
			int nextValue = (int)(Math.random()* (LIMIT+1));
			// Only add in elements that aren't already there
			// This could be an infinite loop--although it's incredibly unlikely
			if (!elements.contains(nextValue))
			{
				elements.add(nextValue);
				++currentSize;
			}
		}
	}
	
	/** Create a random element in this set.
	 * 
	 * @return A randomly selected element between 0 and LIMIT.
	 */
	public static Integer createRandomElement()
	{
		return (int) (Math.random()*(LIMIT+1));
	}
	
	/** Return the union of the implicit set and source.  The union operation
	 * returns values that are in one set or the other set or both.
	 * @param source The second set for the union operation.
	 * @return The union of this set and source.
	 */
	public Set union(Set source)
	{
		Set result = new Set(source); // create a copy of the original set
		
		for (int i=0; i<elements.size(); ++i)
		{
			// If the set
			if (!result.elements.contains(elements.get(i)))
					result.elements.add(elements.get(i));
		}
		
		return result;
	}
	
	/** Return the intersection of the implicit set and source. The intersection
	 * operation returns values that are in both sets.
	 * @param source The second set for the intersection operation.
	 * @return The intersection of this set and source.
	 */
	public Set intersection(Set source)
	{
		Set result = new Set();
		for (int implicit = 0; implicit < this.elements.size(); ++implicit)
		{
			for (int sourceIndex = 0; sourceIndex < source.elements.size(); 
					++sourceIndex )
			{
				if (elements.get(implicit).equals(source.elements.get(sourceIndex)))
				{
					result.elements.add(elements.get(implicit));
				}
			} // end sourceIndex
		} // end implicit
		
		// This should not be necessary if neither of the sets has duplicate
		// elements, but it doesn't hurt to be cautious
		removeDuplicates();
		return result;
	}
	
	/** Return the set difference between the implicit set and source.  The operation is properly
	 * written as this - source.  The set returned will have the elements that are in the implicit
	 * set but not in source.
	 * @param source The second set for the set difference oepration.
	 * @return The elements that are in the implicit set bu tnot in source.
	 */
	public Set setDifference(Set source)
	{
		Set result = new Set(this);
		
		for (int i=0; i<source.elements.size(); ++i)
		{
			// Remove any values that are in source from the result
			if (result.elements.contains(source.elements.get(i)))
			{
				result.elements.remove(source.elements.get(i));
			}
		}
		
		return result;
	}
	
	/** Determine whether the given element is or is not in the implicit set.
	 * 
	 * @param oneElement The element to be tested for set membership.
	 * @return true if oneElement is in the implicit set and false otherwise.
	 */
	public boolean elementOf(Integer oneElement)
	{
		return elements.contains(oneElement);
	}
	
	/** Return whether or not the set has no elements, i.e is an empty set.
	 * 
	 * @return true if the set has no elements, and false otherwise.
	 */
	public boolean isEmpty()
	{
		return elements.isEmpty();
	}
	
	/** Return the complement of the implicit set.  The complement is all of the elements
	 * that are in the Universal set, but are not in the implicit set.
	 * @return  A set containing the values that are in the universal set, but not in the implicit set.
	 */
	public Set complement()
	{
		Set result = new Set();
		
		// Remember <= because LIMIT is inclusive
		for (int i=0; i<=LIMIT; ++i)
		{
			if (!elementOf(i))
			{
				result.elements.add(i);
			}
		}
		
		return result;
	}
	
	/** Print out the elements of the set as a String.
	 * @return A String containing the elements, comma separated, between curly braces.
	 */
	public String toString()
	{
		StringBuilder result = new StringBuilder();
		result.append('{');
		
		// Add the elements to the StringBuilder, one at a time
		for (int index = 0; index< elements.size(); ++index)
		{
			result.append(elements.get(index));
			// Don't put a comma after the last element
			if (index != elements.size()-1)
			{
				result.append(',');
			}
		}
		result.append('}');
		
		return result.toString();
		
		
	}
	
	/** Return whether or not the implicit set has exactly the same elements as source.
	 * 
	 * @param source The set that is compared to the implicit set.
	 * @return If source is null or source contains different elements that the implcit set, return false. 
	 * Otherwise return true.
	 */
	public boolean equals(Set source)
	{
		if (source==null)
		{
			return false;
		}
		
		if (this.elements.size() != source.elements.size())
		{
			return false;
		}
		
		for (int implicit = 0; implicit < elements.size(); 
				++implicit)
		{
			if (!source.elements.contains(elements.get(implicit)))
					return false;
		}
		
		return true;
	}
	
	/** Interpret the String input as a set. The set is expected to contain
	 * curly braces and be comma separated.  Spaces may be included surrounding the
	 * numbers.
	 * 
	 * @param input A String containing the set to be interpreted. Elements
	 * that are not in the universal set are ignored.
	 */
	public void parse(String input)
	{
		// first remove the {}
		StringBuilder sb  = new StringBuilder(input);
		
		// Delete the curly braces, if they are present
		int curlyIndex = sb.indexOf("{");
		if (curlyIndex != -1)
		{
			sb.deleteCharAt(curlyIndex);
		}
		curlyIndex = sb.indexOf("}");
		if (curlyIndex != -1)
		{
			sb.deleteCharAt(curlyIndex);
		}
		
		// Get rid of all existing elements in this object
		elements.clear();
		
		// If there are no characters left, get out of here
		// These cases handle empty sets--{} and { }
		if (sb.length()==0 || sb.toString().trim().isEmpty())
			return;
			
		// The elements are separated by commas and spaces
		String[] setElements = sb.toString().split(",");
		
		// Translate the elements from Strings to Integer objects
		for (int i=0; i<setElements.length; ++i)
		{
			int in = Integer.parseInt(setElements[i].trim());
			if (in >= 0 && in <= LIMIT)
				elements.add(Integer.parseInt(setElements[i].trim()));
		}
			
		// Make sure there weren't any duplicates
		removeDuplicates();
	}
}
