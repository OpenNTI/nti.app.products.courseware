/* Simulate a machine that sells granola bars. 
Each granola bar costs $1.25. 
If the user deposits exactly $1.25, the machine should vend the bar. 
If the user deposits more than $1.25, the money should make change. 
If the user deposits less than $1.25, the machine should request more money.
*/
import java.util.Scanner;

public class VendingMachine 
{

	public static void main(String[] args) 
	{
		Scanner keyboard = new Scanner(System.in);
		
		final int COST_OF_BAR = 130;
		
		int money;
		
		// Get input from user
		System.out.println("Each bar cost $" + COST_OF_BAR/100.0 + ". Please enter your money.");
		money = (int)(keyboard.nextDouble()*100.0+0.5);
		
		// Calculate whether the user needs change or to enter more money
		if (money < COST_OF_BAR)
		{
			System.out.println("Please insert " + (COST_OF_BAR - money)/100.0 );
		} 
		else if (money == COST_OF_BAR)
		{
			System.out.println("Enjoy your candy!");
		}
		else
		{
			System.out.println("Your change is " + (money - COST_OF_BAR)/100.0);
		}
	}

}
