/** Create a two dimensional grid for a Frogger game.
 * The board is ROWS columns tall, and COLS columns wide.
 * These constants are used in several other classes.
 * Row 0 is at the top of the board.
 * Column 0 is at the left of the board.
 * 
 * When the board is displayed, the top and bottom rows will be shown
 * with -, to delimit the board on the screen.
 * 
 * @author Deborah A. Trytten
 *
 */
public class Grid 
{

	// instance data
	private char[][] grid;
	
	// class data
	public final static int ROWS = 7;
	public final static int COLS = 30;
	
	/** Construct a two dimensional grid that is ROWS by COLUMNS characters.
	 * The first and last row will be filled with -, the other rows will be filled
	 * with spaces.
	 */
	public Grid()
	{
		grid = new char[ROWS][COLS];
	}
	
	/** Erase the current contents of the grid and replace them
	 * with an empty board.  An empty board is all spaces, except
	 * that the top and bottom rows are full of - to delimit the board.
	 * 
	 */
	public void clearGrid()
	{
		for (int r = 0; r< ROWS; ++r)
			for (int c = 0; c < COLS; ++c)
				grid[r][c] = ' ';
	}
	
	/** Display the grid to the console.
	 * 
	 */
	public void displayGrid()
	{
		for (int r=0; r < ROWS; ++r)
		{
			for (int c = 0; c < COLS; ++c)
			{
				System.out.print(grid[r][c]);
			}
			System.out.println();
		}
	}
	
	/** Change one character stored in the grid.
	 * 
	 * @param r The rows for the character to be changed.
	 * @param c The column for the character to be changed.
	 * @param symbol The symbol to be placed in the grid.
	 */
	public void setGrid(int r, int c, char symbol)
	{
		if (0<= r && r < ROWS && 0 <= c && c < COLS)	
			grid[r][c] = symbol;
		else
			System.out.println("Illegal Grid position set");
	}
}
