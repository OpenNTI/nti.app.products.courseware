import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;


public class RescueInterface 
{
	private static final int NEW_SEARCH = 1;
	private static final int REFINE_SEARCH = 2;
	private static final int QUIT = 3;
	private static final int AGE = 4;
	private static final int SEX = 5;
	private static final int CATS = 6;
	private static final int KIDS = 7;
	private static final int DOGS = 8;

	/** Allow the user to search for greyhounds that meet their needs.  This method is a little bit longer
	 * than is ideal, but the only reasonable to way to make it significantly shorter would be to move the
	 * while loop into another method--and then the main would be too short.
	 * 
	 * @param args There are no command line arguments.
	 * @throws FileNotFoundException If the file of greyhounds is not found in the default location.
	 */
	public static void main(String[] args) throws FileNotFoundException
	{
		Scanner keyboard = new Scanner(System.in);
		
		// Get the data for the rescue from the file
		GreyhoundRescue fastFriends = new GreyhoundRescue();
		fastFriends.readFromFile();
		
		// This variable will be used for refined searches.  When a search is done on the full
		// list, the result is stored here.  If the user wishes to refine the search, this list
		// is used in future calculations.  If not, a new search is started om the full list.
		ArrayList<Greyhound> hounds=null;
		
		// priming input
		int choice = getSearchChoice(keyboard);
		while (choice != QUIT)
		{
			int minimumAge=0; // initialized to keep the compiler happy
			int maximumAge=0;
			String sex="";
			
			int fieldChoice = getFieldChoice(keyboard);
			
			// Some fields require additional data
			if (fieldChoice == AGE)
			{
				System.out.println("Enter the minimum age");
				minimumAge = keyboard.nextInt();
				System.out.println("Enter the maximum age");
				maximumAge = keyboard.nextInt();
			}
			else if (fieldChoice == SEX)
			{
				System.out.println("Enter Male or Female");
				sex = keyboard.next();
			}
			
			// Now do the searches--either from an existing list (refined) or from the full list (new)
			if (choice==NEW_SEARCH)
			{
				hounds = processNewSearch(fastFriends, fieldChoice, minimumAge, maximumAge, sex);	
			}
			else if (choice == REFINE_SEARCH)
			{
				hounds = processRefinedSearch(hounds, fieldChoice, minimumAge, maximumAge, sex);
			}
			
			System.out.println("The following hounds are available that meet your criteria");
			for (int i=0; i<hounds.size(); ++i)
			{
				System.out.println(hounds.get(i).getName()); // names only
			}
			
			//priming read
			choice = getSearchChoice(keyboard);
		} // end while
		
		// Write out a file of hounds
		fastFriends.writeToFile();
	}
	
	/** Refine the existing search by calling the appropriate method in the GreyhoundRescue class.
	 * 
	 * @param rescue The object that holds the complete list of dogs available to the Rescue.
	 * @param choice AGE, SEX, DOGS, CATS or KIDS, indicating which search should be done next.
	 * @param minAge The minimum age, only valid if choice is AGE.
	 * @param maxAge The maximum age, only valid if choice is AGE.
	 * @param sex male or female (not case sensitive), only valid if choice is SEX.
	 * @return The list of hounds that meet the search criterion.
	 */
	private static ArrayList<Greyhound> processNewSearch(GreyhoundRescue rescue, int choice, int minAge, int maxAge, String sex)
	{
		ArrayList<Greyhound> result;
		
		if (choice==AGE)
		{
			result = rescue.getDogsByAge(minAge, maxAge);
		}
		else if (choice == SEX)
		{
			result = rescue.getDogsBySex(sex);
		}
		else if (choice == CATS)
		{
			result = rescue.getCatSafeDogs();
		}
		else if (choice == KIDS)
		{
			result = rescue.getKidSafeDogs();
		}
		else if (choice == DOGS)
		{
			result = rescue.getSmallDogSafeDogs();
		}
		else
		{
			return null; // should never get here
		}
		
		return result;
	}
	
	/** Refine the existing search by calling the appropriate method in the GreyhoundRescue class.
	 * 
	 * @param hounds The list of hounds selected so far.
	 * @param choice AGE, SEX, DOGS, CATS or KIDS, indicating which search should be done next.
	 * @param minAge The minimum age, only valid if choice is AGE.
	 * @param maxAge The maximum age, only valid if choice is AGE.
	 * @param sex male or female (not case sensitive), only valid if choice is SEX.
	 * @return The list of hounds that meet the search criterion.
	 */
	private static ArrayList<Greyhound> processRefinedSearch(ArrayList<Greyhound> hounds, int choice, int minAge, int maxAge, String sex)
	{
		ArrayList<Greyhound> result;
		
		if (choice==AGE)
		{
			result = GreyhoundRescue.getDogsByAge(hounds, minAge, maxAge);
		}
		else if (choice == SEX)
		{
			result = GreyhoundRescue.getDogsBySex(hounds, sex);
		}
		else if (choice == CATS)
		{
			result = GreyhoundRescue.getCatSafeDogs(hounds);
		}
		else if (choice == KIDS)
		{
			result = GreyhoundRescue.getKidSafeDogs(hounds);
		}
		else if (choice == DOGS)
		{
			result = GreyhoundRescue.getSmallDogSafeDogs(hounds);
		}
		else
		{
			return null; // should never get here
		}
		
		return result;

	}
	
	/** Show a menu of choices for the fields in the search.
	 * 
	 * @param keyboard Attached to the user's keyboard.
	 * @return AGE, SEX, CATS, KIDS< or DOGS, depending on what the user selects.
	 */
	private static int getFieldChoice(Scanner keyboard)
	{
		// show menu
		int choice = -1; // illegal value
		
		// DeMorgan's Laws to the rescue!
		while (choice != AGE && choice != SEX && choice != CATS && choice != KIDS && choice != DOGS)
		{
			System.out.println("Please select from the menu below");
			System.out.println("1. By age");
			System.out.println("2. By sex");
			System.out.println("3. By cat safe");
			System.out.println("4. By kid safe");
			System.out.println("5. By small dog safe");
			
			choice = keyboard.nextInt();
			choice = choice + 3; // to convert the user's way of thinking to our internal system
		}
		return choice;

	}
	
	/** Show a menu of search choice options.
	 * 
	 * @param keyboard Linked to the user's keyboard.
	 * @return The menu choice (NEW_SEARCH, REFINE_SEARCH, or QUIT).
	 */
	private static int getSearchChoice(Scanner keyboard)
	{
		// show menu
		int choice = -1; // illegal value
		
		// DeMorgan's Laws to the rescue!
		while (choice != NEW_SEARCH && choice != REFINE_SEARCH && choice != QUIT)
		{
			System.out.println("Please select from the menu below");
			System.out.println("1. Start a new search");
			System.out.println("2. Refine your last search");
			System.out.println("3. Exit program");
			
			choice = keyboard.nextInt();
		}
		return choice;
		
	}

}
