import java.util.Scanner;
import java.util.Arrays;

public class MiniYahtzee 
{
	final static int TURNS = 6;
	final static int DICE = 5;

	/** Play a game of mini-yahtzee.  The rules for the regular game are here:
	 * http://en.wikipedia.org/wiki/Yahtzee. We will play only with above the line scores.
	 * @param args This program has no command line arguments
	 */
	public static void main(String[] args) 
	{
		Scanner keyboard = new Scanner(System.in);
		
		String namePlayer1;
		String namePlayer2;
		
		System.out.println("Enter the first player's name");
		namePlayer1 = keyboard.nextLine();
		System.out.println("Enter the second player's name");
		namePlayer2 = keyboard.nextLine();
		
		int[] playerOneScores;
		int[] playerTwoScores;
		
		playerOneScores = new int[TURNS];
		playerTwoScores = new int[TURNS];
		
		// A -1 value means that the category has not been played
		Arrays.fill(playerOneScores, -1);
		Arrays.fill(playerTwoScores, -1);
		
		playOneGame(namePlayer1, playerOneScores, namePlayer2, playerTwoScores, keyboard);
		
	}

	/** Allow two players to play one game of Yahtzee.
	 * 
	 * @param name1 The first player's name.
	 * @param player1Score An array, initialized with -1s, containing the first player's score.
	 * @param name2 The second player's name.
	 * @param player2Score An array, inialized with -1s, containing the second player's score.
	 * @param keyboard A Scanner that is attached to the keyboard.
	 */
	public static void playOneGame(String name1, int[] player1Score, String name2, int[] player2Score, Scanner keyboard)
	{
		// Play the game in turns
		int turns = 0;
		
		// The game has one turn for every possible outcome
		while (turns < TURNS)
		{
			// Players alternate playing
			// There is no advantage to playing first
			System.out.println(name1 + " it is your turn.");
			playOneTurn(player1Score, keyboard);
			
			System.out.println(name2 + " it is your turn.");
			playOneTurn(player2Score, keyboard);
			
			turns = turns + 1;
		}
		
		// Find the winner
		int score1 = calculateTotalScore(player1Score);
		System.out.println(name1 + " your score is " + score1 + ".");
	
		int score2 = calculateTotalScore(player2Score);
		System.out.println(name2 + " your score is " + score2 + ".");

		if (score1 > score2)
		{
			System.out.println("Contratulations " + name1 + ".");
		}
		else if (score2 > score1)
		{
			System.out.println("Congratulations " + name2 + ".");
		}
		else
		{
			System.out.println("It's a tie.");
		}
	}
	
	/** Let one player play one turn of Yahtzee.  A turn consists of a roll of 5 dice
	 * then second and third rolls of selected dice if the player wishes.
	 * @param score The score for the game.
	 * @param keyboard The Scanner object for user input.
	 */
	public static void playOneTurn(int[] score, Scanner keyboard)
	{
		int[] dice = new int[DICE];
		
		// Show the user their scorecard
		showCurrentScoreCard(score);
		
		// Roll all of the dice
		rollAllDice(dice);
		
		// Show the dice to the user
		showDice(dice);
		
		// Let them reroll the dice
		reRollDice(dice, keyboard);
		
		// Show the dice to the user
		showDice(dice);
		
		// Let the reroll the dice again
		reRollDice(dice, keyboard);
		
		// Score the rolls
		
		// Show the user the dice
		showDice(dice);
		
		// Ask them for a category to score
		System.out.println("Which category would you like to score in");
		int category = keyboard.nextInt(); // unit indexed
		keyboard.nextLine(); // get rid of return
		
		category = category - 1; // zero indexed
		
		while (category < 0 || category >= TURNS || score[category] != -1)
		{
			System.out.println("That is not a legal category, remember you cannot rescore in a category");
			System.out.println("Please enter the category you would like to score in");
			category = keyboard.nextInt(); // unit indexed
			keyboard.nextLine(); // get rid of new line
			category = category - 1; // zero indexed
		}
		// Score that category
		score[category] = sumOfDice(dice, category+1); // category is unit indexed in the method
	}
	
	/** Allow the user to select which dice are rolled again.
	 * 
	 * @param dice An array containing the current values on the dice, before and after the reroll.
	 * @param keyboard A Scanner object that allows interaction with the keyboard.
	 */
	public static void reRollDice(int[] dice, Scanner keyboard)
	{
		System.out.println("Which dice would you like to reroll, enter -1 if you do not wish to reroll");
		String inputLine = keyboard.nextLine();
		
		Scanner line = new Scanner(inputLine);
	
		while (line.hasNextInt())
		{
			int reRollValue = line.nextInt(); // unit indexed
			
			if (reRollValue == -1)
				return;
			
			if (reRollValue <= 0 || reRollValue > DICE)
			{
				System.out.println("That is not a legal value, no dice will be rolled again");
			}
			else
			{
				dice[reRollValue-1] = (int)(Math.random()*6.0) + 1;
			}
		}
	
	} // end reRollDice
	
	/** Calculate the total score.  A value of -1 indicates
	 * that a category has not yet been used and should not
	 * be counted.
	 * @param score An array containing the current scores.
	 * @return
	 */
	public static int calculateTotalScore(int[] score)
	{
		int sum = 0;
		int index = 0;
		
		// Add up everything that is not -1
		while (index < score.length)
		{
			// Scores of -1 flag unused rows
			if (score[index] != -1)
			{
				sum = sum + score[index];
			}
			
			index = index + 1;
		}
		
		return sum;
	}

	/** Find the sum of the dice using yahtzee rules. Only
	 * dice containing the given number are counted.
	 * @param dice An array containing the values on the dice.
	 * @param number The number of the value that is to be counted.
	 * @return
	 */
	public static int sumOfDice(int[] dice, int number)
	{
		int sum = 0;
		int index = 0;
		
		while (index < dice.length)
		{
			// Only dice that equal the given number count
			if (dice[index] == number)
			{
				sum = sum + dice[index];
			}
			index = index + 1;
		}
		
		return sum;
	}

	/** Show the value on the dice to the user.
	 * 
	 * @param dice An array containing all of the dice.
	 */
	public static void showDice(int[] dice)
	{
		int index = 0;
		while (index < DICE)
		{
			System.out.println((index+1) + ". " + dice[index]);
			index = index+1;
		}
	}
	
	/** Roll all of the dice.
	 * 
	 * @param dice The rolled dice values are stored here.
	 */
	public static void rollAllDice(int dice[])
	{
		int index = 0;
		
		while (index < dice.length)
		{
			dice[index] = (int)(Math.random() * TURNS)+1;
			index = index + 1;
		}
	}
	
	/** Show the user their current score.
	 * 
	 * @param score The array containing the user scores.
	 */
	public static void showCurrentScoreCard(int[] score)
	{
		int count = 0;
		while (count < score.length)
		{
			if (score[count] != -1)
				System.out.println("Current score for die " + (count+1) + " is " + score[count]);
			else
				System.out.println("Category " + (count+1) + " has not been used yet");
			count = count +1;
		}
	}
}
