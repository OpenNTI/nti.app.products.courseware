import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
/** This program merges a file of sorted data with a file of unsorted data and
 * saves the result to a single file. The format for the files is the number of 
 * lines, followed by one String for each line.
 * @author Deborah Trytten
 * @version 1.0
 *
 */
public class CombinePartiallySortedData 
{

	/** Run the program. You'll be asked for the names of the two input files,
	 * sorted first, and then unsorted and then for the output file.
	 * @param args There are no command line arguments.
	 * @throws FileNotFoundException If any files you request are not available.
	 */
	public static void main(String[] args) throws FileNotFoundException
	{
		Scanner keyboard = new Scanner(System.in);
		
		String sortedFileName;
		String unsortedFileName;
		String outputFileName;
		
		System.out.println("Enter the name of the sorted file");
		sortedFileName = keyboard.next();
		System.out.println("Enter the name of the unsorted file");
		unsortedFileName = keyboard.next();
		System.out.println("Enter the name of the file to save data to");
		outputFileName = keyboard.next();

		Scanner sortedFile = new Scanner(new File(sortedFileName));
		int sortedSize = sortedFile.nextInt();
		sortedFile.nextLine(); // get rid of newline character
		
		Scanner unsortedFile = new Scanner(new File(unsortedFileName));
		int unsortedSize = unsortedFile.nextInt();
		unsortedFile.nextLine(); // get rid of newline character

		String[] data = readFiles(sortedFile, unsortedFile, sortedSize, unsortedSize);
		sortedFile.close();
		unsortedFile.close();
		
		sortMergedData(data, sortedSize);
		
		saveToFile(outputFileName, data);
	}

	/** Save the array of data to the file, removing duplicate entries.
	 * 
	 * @param fileName The name of the file.
	 * @param data The array of data to save.
	 * @throws FileNotFoundException If the file is not writable.
	 */
	public static void saveToFile(String fileName, String[] data) throws FileNotFoundException
	{
		PrintWriter file = new PrintWriter(new File(fileName));
		
		// count duplicates
		int duplicates = 0;
		for (int i=1; i<data.length; ++i)
		{
			if (data[i].equals(data[i-1]))
					++duplicates;
		}
		
		file.println(data.length-duplicates);
		
		if (data.length != 0)
			file.println(data[0]);
		
		for (int i=1; i<data.length; ++i)
		{
			if (!data[i].equals(data[i-1]))
					file.println(data[i]);
		}
		
		file.close();
	}
	
	/** Sort the data in the array.  Up to index sortedSize (exclusive) the 
	 * data is already sorted.  After that it is not.  The algorithm used is a modified
	 * selection sort.
	 * @param data An array that contains sorted data in indices 0 to sortedSize-1, and unsorted
	 * data in the remainder of the array.
	 * @param sortedSize The number of elements at the start of the array that are sorted.
	 */
	public static void sortMergedData(String[] data, int sortedSize)
	{
		int minIndex;
		
		// Work through one element at a time
		for (int index=0; index < data.length; ++index)
		{
			// find the next minimum value and put it in the proper position
				minIndex = index;
				
				// If we're still in the sorted data, start at the first element in the unsorted data
				// If we're in the unsorted data, start at the next element
				int next;
				if (index<sortedSize)
					next = sortedSize; // still searching the unsorted data
				else
					next = index+1;
				
				// Find the smallest value
				for ( ; next < data.length; ++next)
				{
					if (data[next].compareTo(data[minIndex]) < 0)
					{
						minIndex = next;
					}
				}
				
				// swap the data
				if (minIndex != index)
				{
					String temp = data[minIndex];
					data[minIndex] = data[index];
					data[index] = temp;
				}
		}
	}
	
	/** Read data from two files into a single array. The first file contains sortedSize elements of sorted data.
	 * The second file contains unsortedSize elements of unsorted data. The array should have the sorted data before
	 * the unsorted data.
	 * @param sortedFile A Scanner linked to the sorted file.
	 * @param unsortedFile A Scanner linked to the unsorted file.
	 * @param sortedSize The number of lines of data in the sorted file.
	 * @param unsortedSize The number of lines of data in the unsorted file.
	 * @return An array with unsorted data before sorted data.
	 */
	public static String[] readFiles(Scanner sortedFile, Scanner unsortedFile, int sortedSize, int unsortedSize) 
	{
		String[] result = new String[sortedSize + unsortedSize];
		
		int index=0;
		for ( ; index < sortedSize && sortedFile.hasNextLine(); ++index)
		{
			result[index] = sortedFile.nextLine();
		}
		
		if (index != sortedSize)
			System.out.println("The file was not of the correct length");
		
		for ( ; index < (sortedSize + unsortedSize) && unsortedFile.hasNextLine(); ++ index)
		{
			result[index] = unsortedFile.nextLine();
		}
		
		if (index != sortedSize + unsortedSize)
			System.out.println("The file was not of the correct length");

		
		return result;
	}
}
