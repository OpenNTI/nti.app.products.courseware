import java.util.ArrayList;
import java.util.Collections;

/** Store multiple pairs of String objects.  The first object is the key, the
 * second is the value.   The class name comes from the similarity of this structure
 * to a traditional dictionary where a word (key) is used to look up a definition (value).
 * 
 * @author Deborah A. Trytten
 * @version 1.0
 *
 */
public class Dictionary 
{
	
	private ArrayList<StringPair> dictionary;
	
	/** Construct an empty dictionary.
	 * 
	 */
	public Dictionary()
	{
		dictionary = new ArrayList<StringPair> ();
	}
	
	/** Insert a new key and value in to the dictionary.  If they key is 
	 * already in the dictionary the method returns without making any
	 * changes.
	 * 
	 * @param key The key to insert--must not be in the dictionary already.
	 * @param value The value to insert.
	 */
	public void put(String key, String value)
	{
		if (findKeyIndex(key) == -1)
		{
			StringPair element = new StringPair(key, value);
			dictionary.add(element);
		}
	}
	
	/** Remove the pair (if any) in the dictionary with this key.
	 * 
	 * @param key They key for the (key, value) pair to remove.
	 */
	public void remove(String key)
	{
		int index = findKeyIndex(key);
		if (index == -1)
			return;
		
		dictionary.remove(index);
	}
	
	/** Return the value that is paired with this key.
	 * 
	 * @param key The primary key for the search.
	 * @return The matching value.
	 */
	public String getValue(String key)
	{
		int index = findKeyIndex(key);
		StringPair pair = dictionary.get(index);
		return pair.getValue();
	}
	
	/** Find the index for the pair with the matching key.
	 * 
	 * @param key The key to match.
	 * @return The index of the matching key, or -1 if the
	 * key is not in the dictionary.
	 */
	private int findKeyIndex(String key)
	{
		for(int index = 0; index< dictionary.size(); ++index)
		{
			StringPair pair = dictionary.get(index);
			String first = pair.getKey();
			if (key.equals (first))
				return index;
		}
		
		return -1;
	}
	
	/** Return whether the dictionary is empty or not.
	 * 
	 * @return True if the dictionary is empty and false otherwise.
	 */
	public boolean isEmpty()
	{
		return dictionary.isEmpty();
	}

	/** Return the key values only.
	 * 
	 * @return An ArrayList containing all keys that are currently stored in the 
	 * dictionary.
	 */
	public ArrayList<String> keys()
	{
		ArrayList<String> result = new ArrayList<String>();
		for(StringPair p: dictionary)
			result.add(p.getKey());
		
		return result;
	}
}
