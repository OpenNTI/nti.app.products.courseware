import java.text.DecimalFormat;

/** This class stores items that are donated to a charity.
 * The class contains a name for each item and a price.
 * 
 * @author Deborah  A. Trytten
 *
 */
public class DonatedItem 
{

	private String name;
	private double price;
	
	/** Construct a donated item with the given name and price.
	 * 
	 * @param item  The name of the item (e.g "women's shirt").
	 * @param price The price of the item.
	 */
	public DonatedItem(String item, double priceOfItem)
	{
		name = item;
		price = priceOfItem;
	}
	
	/** Return the name of the item.
	 * 
	 * @return The item's name.
	 */
	public String getItemName()
	{
		return name;
	}
	
	/** Return the price of the item.
	 * 
	 * @return  The item's price.
	 */
	public double getItemPrice()
	{
		return price;
	}
	
	/** Show the item as a String.  The result shown is
	 * name: price.
	 * @return A String containing the items' name, a colon, and the price.
	 */
	public String toString()
	{
		return "Item name: " + name + " Item price: " + price;
	}
}
