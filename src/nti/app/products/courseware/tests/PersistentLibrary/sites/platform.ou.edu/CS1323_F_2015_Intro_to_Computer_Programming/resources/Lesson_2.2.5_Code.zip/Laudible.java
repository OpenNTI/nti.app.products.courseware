/* I have a subscription to Laudible.com, an online retailer 
 * that sells audio books. 
 * Each month I get one credit for a fixed fee of $14.95. 
 * Each book has a title, a length in hours and minutes, 
 * and a number of credits
 * Write a program that reads data for books and chooses 
 * the one that is the best value
 * End the input with a sentinel of END
 */

import java.util.Scanner;

public class Laudible 
{

	public static void main(String[] args) 
	{
		Scanner keyboard = new Scanner (System.in);
		
		String bestTitle = readAndFindCheapestBook(keyboard);
		System.out.println("The cheapest book is " + bestTitle);
	}

	public static String readAndFindCheapestBook(Scanner input)
	{
		String title;
		int hours;
		int minutes;
		int credits;
		
		//Priming Reads
		System.out.println("Enter the title of your book on one line.");
		System.out.println("And the hours, minutes, and credits on another line.");
		System.out.println("Enter END when the program is finished.");
		
		title = input.nextLine();
		hours = input.nextInt();
		minutes = input.nextInt();
		credits = input.nextInt();
		input.nextLine(); // Read in the carriage return at the end of the line
		
		// Keep track of the minimum
		double maximumMinutesPerCredit = ((hours * 60) + minutes) 	
											/ (double) credits;
		String cheapestBookSoFar = title;
		
		while (!title.equals("END"))
		{
			// Calculate the cost per minute
			double minutesPerCredit;
			minutesPerCredit = ((hours * 60) + minutes) / (double) credits;
			
			// Find whether the current element is the minimum
			if (minutesPerCredit > maximumMinutesPerCredit)
			{
				cheapestBookSoFar = title;
				maximumMinutesPerCredit = minutesPerCredit;
			}
			
			//Priming Reads
			System.out.println("Enter the title of your book on one line.");
			System.out.println("And the hours, minutes, and credits on another line.");
			System.out.println("Enter END when the program is finished.");
			
			title = input.nextLine();
			
			if (!title.equals("END"))
			{
				hours = input.nextInt();
				minutes = input.nextInt();
				credits = input.nextInt();
				input.nextLine(); // Read in the carriage return at the end of the line
			}
		}
		
		return cheapestBookSoFar;
	}
}
